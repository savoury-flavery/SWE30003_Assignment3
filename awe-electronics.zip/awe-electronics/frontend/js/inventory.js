document.addEventListener('DOMContentLoaded', () => {
  Inventory.init();
});

const Inventory = (() => {
  let products = [];

  async function loadProducts() {
    try {
      const res = await fetch('/api/products');
      if (!res.ok) throw new Error('Failed to load inventory');
      products = await res.json();
    } catch (err) {
      alert('Error loading inventory: ' + err.message);
      products = [];
    }
  }

  function renderInventoryTable() {
    const tbody = document.querySelector('#inventoryTable tbody');
    if (!tbody) return;

    tbody.innerHTML = '';

    products.forEach(product => {
      const id = product.id; 
      tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${id}</td>
        <td>${product.name}</td>
        <td>${product.category}</td>
        <td>
          <input 
            type="number" 
            min="0" 
            value="${product.stocklevel}" 
            data-id="${id}"
            style="width:70px"
          />
        </td>
        <td>
          <button class="btn" data-id="${id}">Update</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('button').forEach(button => {
      button.addEventListener('click', async () => {
        const id = button.getAttribute('data-id');
        const input = tbody.querySelector(`input[data-id='${id}']`);
        const newStock = parseInt(input.value, 10);

        if (isNaN(newStock) || newStock < 0) {
          alert('Please enter a valid non-negative number for stock.');
          return;
        }

        await updateStock(id, newStock);
      });
    });
  }

  async function updateStock(id, newStock) {
    try {
      const res = await fetch(`/api/inventory/${id}/stock`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ stock: newStock }),
      });

      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.error || 'Failed to update stock');
      }

      const data = await res.json();
      alert(data.message || 'Stock updated successfully.');

      // Update local copy and rerender
      const product = products.find(p => p.id == id);
      if (product) product.stocklevel = newStock;
      renderInventoryTable();
    } catch (err) {
      alert('Error updating stock: ' + err.message);
    }
  }

  async function init() {
    await loadProducts();
    renderInventoryTable();
  }

  return { init };
})();
