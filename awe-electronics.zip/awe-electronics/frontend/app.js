// Static fallback products data for initial load or fallback
const staticProducts = [
  {
    id: '1',
    name: 'Laptop Pro',
    price: 1200,
    category: 'laptops',
    image: 'https://via.placeholder.com/150',
    description: 'A high-performance laptop for professionals.',
    specifications: {}
  },
  {
    id: '2',
    name: 'Smartphone X',
    price: 800,
    category: 'phones',
    image: 'https://via.placeholder.com/150',
    description: 'The latest smartphone with an amazing camera.',
    specifications: {}
  },
  {
    id: '3',
    name: 'Wireless Headphones',
    price: 150,
    category: 'accessories',
    image: 'https://via.placeholder.com/150',
    description: 'Comfortable over-ear headphones with noise cancellation.',
    specifications: {}
  },
  {
    id: '4',
    name: 'Digital Camera',
    price: 600,
    category: 'cameras',
    image: 'https://via.placeholder.com/150',
    description: 'Capture stunning photos and videos.',
    specifications: {}
  },
  {
    id: '5',
    name: 'Smart Refrigerator',
    price: 2000,
    category: 'appliances',
    image: 'https://via.placeholder.com/150',
    description: 'A smart fridge with a built-in touchscreen.',
    specifications: {}
  },
];

// Simple elements
const productGrid = document.getElementById('productGrid');
const singleProductView = document.getElementById('singleProduct');

// Fallback display function using static products
function displayProducts(filteredProducts = staticProducts) {
  productGrid.innerHTML = ''; // Clear existing products
  filteredProducts.forEach((product) => {
    const productCard = document.createElement('div');
    productCard.classList.add('product-card');
    productCard.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <h3>${product.name}</h3>
      <p>£${product.price.toFixed(2)}</p>
      <button onclick="productCatalogue.showProductDetails('${product.id}')">View Details</button>
      <button onclick="productCatalogue.addToCart('${product.id}')">Add to Cart</button>
    `;
    productGrid.appendChild(productCard);
  });
  productGrid.style.display = 'flex';
  singleProductView.style.display = 'none';
}

window.goToLogin = () => {
  window.location.href = "login.html";
};

window.goToAccount = () => {
  window.location.href = "account.html";
};

window.viewCart = () => {
  alert("Cart feature coming soon!");
};

// The advanced ProductCatalogue class managing dynamic product loading, filtering, sorting, pagination, modal, and cart
class ProductCatalogue {
    constructor() {
        this.products = [];
        this.filteredProducts = [];
        this.currentPage = 1;
        this.productsPerPage = 8;
        this.searchTerm = '';
        this.selectedCategory = '';
        this.sortBy = 'name-asc';

        // DOM Elements
        this.productGrid = document.getElementById('productGrid');
        this.searchInput = document.getElementById('searchInput');
        this.searchButton = document.getElementById('searchButton');
        this.categoryFilter = document.getElementById('categoryFilter');
        this.sortBySelect = document.getElementById('sortBy');
        this.prevPageBtn = document.getElementById('prevPage');
        this.nextPageBtn = document.getElementById('nextPage');
        this.pageInfo = document.getElementById('pageInfo');
        this.modal = document.getElementById('productModal');
        this.closeModal = document.querySelector('.close');

        // Initialize
        this.init();
    }

    async init() {
        await this.loadProducts();
        this.addEventListeners();
        this.applyFilters();
    }

    async loadProducts() {
        try {
            const response = await fetch('/api/products');
            if (!response.ok) throw new Error('Network response was not ok');
            this.products = await response.json();

            // If no products fetched, use static fallback
            if (!this.products.length) {
                this.products = staticProducts;
            }
        } catch (error) {
            console.error('Error loading products:', error);
            this.products = staticProducts; // fallback static products
        }
        this.filteredProducts = [...this.products];
    }

    addEventListeners() {
        if (this.searchInput) {
          let debounceTimeout;
          this.searchInput.addEventListener('input', () => {
              clearTimeout(debounceTimeout);
              debounceTimeout = setTimeout(() => this.handleSearch(), 300);
          });
        }
        if (this.searchButton) this.searchButton.addEventListener('click', () => this.handleSearch());
        if (this.categoryFilter) this.categoryFilter.addEventListener('change', () => this.handleFilter());
        if (this.sortBySelect) this.sortBySelect.addEventListener('change', () => this.handleSort());
        if (this.prevPageBtn) this.prevPageBtn.addEventListener('click', () => this.previousPage());
        if (this.nextPageBtn) this.nextPageBtn.addEventListener('click', () => this.nextPage());
        if (this.closeModal) this.closeModal.addEventListener('click', () => this.closeProductModal());
        window.addEventListener('click', (e) => {
            if (e.target === this.modal) this.closeProductModal();
        });
    }

    handleSearch() {
        this.searchTerm = this.searchInput ? this.searchInput.value.toLowerCase().trim() : '';
        this.currentPage = 1;
        this.applyFilters();
    }

    handleFilter() {
        this.selectedCategory = this.categoryFilter ? this.categoryFilter.value : '';
        this.currentPage = 1;
        this.applyFilters();
    }

    handleSort() {
        this.sortBy = this.sortBySelect ? this.sortBySelect.value : 'name-asc';
        this.applyFilters();
    }

    applyFilters() {
        this.filteredProducts = this.products.filter(product => {
            const matchesSearch =
                product.name.toLowerCase().includes(this.searchTerm) ||
                product.description.toLowerCase().includes(this.searchTerm);
            const matchesCategory =
                !this.selectedCategory || this.selectedCategory === 'all' || product.category === this.selectedCategory;
            return matchesSearch && matchesCategory;
        });

        this.sortProducts();
        this.currentPage = 1;
        this.updatePagination();
        this.renderProducts();
    }

    sortProducts() {
        const [field, direction] = this.sortBy.split('-');
        this.filteredProducts.sort((a, b) => {
            let comparison = 0;
            if (field === 'name') {
                comparison = a.name.localeCompare(b.name);
            } else if (field === 'price') {
                comparison = a.price - b.price;
            }
            return direction === 'asc' ? comparison : -comparison;
        });
    }

    updatePagination() {
        const totalPages = Math.max(1, Math.ceil(this.filteredProducts.length / this.productsPerPage));
        if (this.prevPageBtn) this.prevPageBtn.disabled = this.currentPage <= 1;
        if (this.nextPageBtn) this.nextPageBtn.disabled = this.currentPage >= totalPages;
        if (this.pageInfo) this.pageInfo.textContent = `Page ${this.currentPage} of ${totalPages}`;
    }

    previousPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.updatePagination();
            this.renderProducts();
        }
    }

    nextPage() {
        const totalPages = Math.ceil(this.filteredProducts.length / this.productsPerPage);
        if (this.currentPage < totalPages) {
            this.currentPage++;
            this.updatePagination();
            this.renderProducts();
        }
    }

    renderProducts() {
        const start = (this.currentPage - 1) * this.productsPerPage;
        const end = start + this.productsPerPage;
        const productsToShow = this.filteredProducts.slice(start, end);

        if (productsToShow.length === 0) {
            this.productGrid.innerHTML = `<p class="no-products">No products found.</p>`;
            if (this.pageInfo) this.pageInfo.textContent = '';
            if (this.prevPageBtn) this.prevPageBtn.disabled = true;
            if (this.nextPageBtn) this.nextPageBtn.disabled = true;
            return;
        }

        this.productGrid.innerHTML = productsToShow
        .map(product => `
            <div class="product-card">
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>£${product.price.toFixed(2)}</p>
                <button class="btn" onclick="productCatalogue.showProductDetails('${product.id}')">View Details</button>
                <button class="btn" onclick="productCatalogue.addToCart('${product.id}')">Add to Cart</button>
            </div>
        `).join('');
    }

    showProductDetails(productId) {
        const product = this.products.find(p => p.id === productId);
        if (!product) return;

        const productDetails = document.getElementById('productDetails') || singleProductView;
        if (!productDetails) return;

        productDetails.innerHTML = `
            <div class="product-details">
                <img src="${product.image}" alt="${product.name}" style="width:300px;">
                <h2>${product.name}</h2>
                <p>Description: ${product.description}</p>
                <p>Price: £${product.price.toFixed(2)}</p>
                <button class="btn" onclick="productCatalogue.addToCart('${product.id}')">Add to Cart</button>
                <button class="btn" onclick="productCatalogue.closeProductModal()">Close</button>
            </div>
        `;

        // If modal exists, show modal, else use single product view
        if (this.modal) {
          this.modal.style.display = 'block';
          this.productGrid.style.display = 'none';
          if (singleProductView) singleProductView.style.display = 'none';
        } else {
          this.productGrid.style.display = 'none';
          singleProductView.style.display = 'block';
        }
    }

    closeProductModal() {
        if (this.modal) this.modal.style.display = 'none';
        if (this.productGrid) this.productGrid.style.display = 'flex';
        if (singleProductView) singleProductView.style.display = 'none';
    }

    async addToCart(productId) {
        const product = this.products.find(p => p.id === productId);
        if (!product) {
            alert('Product not found.');
            return;
        }

        try {
            const res = await fetch('/api/cart', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ productId: product.id })
            });

            if (!res.ok) throw new Error('Failed to add to cart');

            const result = await res.json();
            alert(`${product.name} added to cart!`);

            // Update cart badge if exists
            const cartBadge = document.querySelector('.cart-badge');
            if (cartBadge) {
                const currentCount = parseInt(cartBadge.textContent) || 0;
                cartBadge.textContent = currentCount + 1;
            }
        } catch (err) {
            console.error('Add to cart failed:', err);
            alert('There was a problem adding the product to your cart.');
        }
    }
}

// Initialize product catalogue instance
const productCatalogue = new ProductCatalogue();

// Fallback initial display if no dynamic elements or API available
if (!document.getElementById('searchInput')) {
  displayProducts();
}
