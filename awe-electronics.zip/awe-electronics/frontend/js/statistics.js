const Statistics = (() => {
  let statsData = null;

  async function loadStats() {
    try {
      const res = await fetch('http://localhost:3000/api/stats');
      if (!res.ok) throw new Error('Failed to load stats');
      statsData = await res.json();
    } catch (err) {
      console.error('Error loading stats:', err);
      const ul = document.getElementById('topCategories');
      if (ul) ul.innerHTML = '<li>Error loading statistics data.</li>';
    }
  }

  function getTopCategories(categorySales, topN = 5) {
    return Object.entries(categorySales || {})
      .sort((a, b) => b[1] - a[1])
      .slice(0, topN);
  }

  function renderCategoryList(categorySales) {
    const ul = document.getElementById('topCategories');
    if (!ul) return;
    ul.innerHTML = '';
    const topCategories = getTopCategories(categorySales);
    if (topCategories.length === 0) {
      ul.innerHTML = '<li>No category sales data available.</li>';
      return;
    }
    topCategories.forEach(([category, sales]) => {
      const li = document.createElement('li');
      li.textContent = `${category}: $${sales.toFixed(2)}`;
      ul.appendChild(li);
    });
  }

  function renderStats(period) {
    const totalSalesElem = document.getElementById('totalSales');
    if (!statsData || !totalSalesElem) return;

    let aggCategorySales = {};
    let totalSales = 0;

    if (period === 'daily') {
      // dailyStats is now an object, not an array
      const daily = statsData.dailyStats || {};
      totalSales = daily.totalSales || 0;
      aggCategorySales = daily.categorySales || {};
    } else if (period === 'weekly') {
      totalSales = statsData.weeklyStats?.totalSales || 0;
      aggCategorySales = statsData.weeklyStats?.categorySales || {};
    } else if (period === 'monthly') {
      totalSales = statsData.monthlyStats?.totalSales || 0;
      aggCategorySales = statsData.monthlyStats?.categorySales || {};
    } else if (period === 'yearly') {
      totalSales = statsData.yearlyStats?.totalSales || 0;
      aggCategorySales = statsData.yearlyStats?.categorySales || {};
    }

    totalSalesElem.textContent = totalSales.toFixed(2);
    renderCategoryList(aggCategorySales);
  }

  function setupPeriodSelector() {
    const select = document.getElementById('statsPeriod');
    if (!select) return;
    select.addEventListener('change', () => {
      renderStats(select.value);
    });
  }

  async function init() {
    await loadStats();
    setupPeriodSelector();
    const select = document.getElementById('statsPeriod');
    if (select) renderStats(select.value);
  }

  return { init };
})();
