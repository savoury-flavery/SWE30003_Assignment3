// Product Catalogue System
class ProductCatalogue {
    constructor() {
        this.products = [];
        this.filteredProducts = [];
        this.currentPage = 1;
        this.productsPerPage = 8;
        this.searchTerm = '';
        this.selectedCategory = '';
        this.sortBy = 'name-asc';

        // DOM Elements
        this.productGrid = document.getElementById('productGrid');
        this.searchInput = document.getElementById('searchInput');
        this.searchButton = document.getElementById('searchButton');
        this.categoryFilter = document.getElementById('categoryFilter');
        this.sortBySelect = document.getElementById('sortBy');
        this.prevPageBtn = document.getElementById('prevPage');
        this.nextPageBtn = document.getElementById('nextPage');
        this.pageInfo = document.getElementById('pageInfo');
        this.modal = document.getElementById('productModal');
        this.closeModal = document.querySelector('.close');

        // Initialize
        this.init();
    }

    async init() {
        await this.loadProducts();
        this.addEventListeners();
        this.applyFilters();
    }

    async loadProducts() {
        try {
            const response = await fetch('/api/products');
            this.products = await response.json();
            this.filteredProducts = [...this.products];
        } catch (error) {
            console.error('Error loading products:', error);
            this.products = [];
            this.filteredProducts = [];
        }
    }

    addEventListeners() {
        // Search with debounce (optional)
        let debounceTimeout;
        this.searchInput.addEventListener('input', () => {
            clearTimeout(debounceTimeout);
            debounceTimeout = setTimeout(() => this.handleSearch(), 300);
        });
        this.searchButton.addEventListener('click', () => this.handleSearch());

        // Filters and sorting
        this.categoryFilter.addEventListener('change', () => this.handleFilter());
        this.sortBySelect.addEventListener('change', () => this.handleSort());

        // Pagination
        this.prevPageBtn.addEventListener('click', () => this.previousPage());
        this.nextPageBtn.addEventListener('click', () => this.nextPage());

        // Modal close handlers
        this.closeModal.addEventListener('click', () => this.closeProductModal());
        window.addEventListener('click', (e) => {
            if (e.target === this.modal) this.closeProductModal();
        });
    }

    handleSearch() {
        this.searchTerm = this.searchInput.value.toLowerCase().trim();
        this.currentPage = 1;
        this.applyFilters();
    }

    handleFilter() {
        this.selectedCategory = this.categoryFilter.value;
        this.currentPage = 1;
        this.applyFilters();
    }

    handleSort() {
        this.sortBy = this.sortBySelect.value;
        this.applyFilters();
    }

    applyFilters() {
        this.filteredProducts = this.products.filter(product => {
            const matchesSearch =
                product.name.toLowerCase().includes(this.searchTerm) ||
                product.description.toLowerCase().includes(this.searchTerm);
            const matchesCategory =
                !this.selectedCategory || product.category === this.selectedCategory;
            return matchesSearch && matchesCategory;
        });

        this.sortProducts();
        this.currentPage = 1;  // Reset page after filtering/sorting
        this.updatePagination();
        this.renderProducts();
    }

    sortProducts() {
        const [field, direction] = this.sortBy.split('-');
        this.filteredProducts.sort((a, b) => {
            let comparison = 0;
            if (field === 'name') {
                comparison = a.name.localeCompare(b.name);
            } else if (field === 'price') {
                comparison = a.price - b.price;
            }
            return direction === 'asc' ? comparison : -comparison;
        });
    }

    updatePagination() {
        const totalPages = Math.max(1, Math.ceil(this.filteredProducts.length / this.productsPerPage));
        this.prevPageBtn.disabled = this.currentPage <= 1;
        this.nextPageBtn.disabled = this.currentPage >= totalPages;
        this.pageInfo.textContent = `Page ${this.currentPage} of ${totalPages}`;
    }

    previousPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.updatePagination();
            this.renderProducts();
        }
    }

    nextPage() {
        const totalPages = Math.ceil(this.filteredProducts.length / this.productsPerPage);
        if (this.currentPage < totalPages) {
            this.currentPage++;
            this.updatePagination();
            this.renderProducts();
        }
    }

    renderProducts() {
        const start = (this.currentPage - 1) * this.productsPerPage;
        const end = start + this.productsPerPage;
        const productsToShow = this.filteredProducts.slice(start, end);

        if (productsToShow.length === 0) {
            this.productGrid.innerHTML = `<p class="no-products">No products found.</p>`;
            this.pageInfo.textContent = '';
            this.prevPageBtn.disabled = true;
            this.nextPageBtn.disabled = true;
            return;
        }

        this.productGrid.innerHTML = productsToShow.map(product => this.createProductCard(product)).join('');
    }

    createProductCard(product) {
        return `
            <div class="product-card">
                <img src="${product.image}" alt="${product.name}" class="product-image" />
                <div class="product-info">
                    <h3 class="product-title">${product.name}</h3>
                    <p class="product-price">$${product.price.toFixed(2)}</p>
                    <button class="btn" onclick="productCatalogue.showProductDetails('${product.id}')">View Details</button>
                    <button class="btn" onclick="productCatalogue.addToCart('${product.id}')">Add to Cart</button>
                </div>
            </div>
        `;
    }

    showProductDetails(productId) {
        const product = this.products.find(p => p.id === productId);
        if (!product) return;

        const productDetails = document.getElementById('productDetails');
        productDetails.innerHTML = `
            <div class="product-details">
                <img src="${product.image}" alt="${product.name}" class="product-details-image" />
                <div class="product-details-info">
                    <h2>${product.name}</h2>
                    <p class="product-details-price">$${product.price.toFixed(2)}</p>
                    <p class="product-details-description">${product.description}</p>
                    <div class="product-details-specs">
                        <h3>Specifications</h3>
                        <ul>
                            ${Object.entries(product.specifications).map(([key, value]) =>
                                `<li><strong>${key}:</strong> ${value}</li>`).join('')}
                        </ul>
                    </div>
                    <button class="btn btn-primary" onclick="productCatalogue.addToCart('${product.id}')">Add to Cart</button>
                </div>
            </div>
        `;

        this.modal.style.display = 'block';
    }

    closeProductModal() {
        this.modal.style.display = 'none';
    }

    async addToCart(productId) {
        const product = this.products.find(p => p.id === productId);
        if (!product) {
            console.error('Product not found:', productId);
            return;
        }

        try {
            const res = await fetch('/api/cart', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ productId: product.id }) // just send ID, server should handle cart addition
            });

            if (!res.ok) throw new Error('Failed to add to cart');

            const result = await res.json();
            alert(`${product.name} added to cart!`);
            console.log('Server response:', result);

            // Update cart badge if exists
            const cartBadge = document.querySelector('.cart-badge');
            if (cartBadge) {
                const currentCount = parseInt(cartBadge.textContent) || 0;
                cartBadge.textContent = currentCount + 1;
            }

        } catch (err) {
            console.error('Add to cart failed:', err);
            alert('There was a problem adding the product to your cart.');
        }
    }
}

// Initialize the product catalogue
const productCatalogue = new ProductCatalogue();
