const express = require('express');
const router = express.Router();

// Middleware to check admin session
const checkAdmin = (req, res, next) => {
  if (!req.session.userId || !req.session.isAdmin) {
    return res.status(403).json({ error: 'Access denied' });
  }
  next();
};

// Dashboard overview using Statistics class
router.get('/admin/dashboard', checkAdmin, async (req, res) => {
  try {
    await statistics.loadData();

    const totalRevenue = statistics.getTotalRevenue();
    const totalOrders = statistics.getTotalOrders();
    const totalProductsSold = statistics.getTotalProductsSold();
    const lowStockProducts = statistics.getLowStockProducts(10);
    const monthlyRevenue = statistics.getMonthlySalesRevenue();

    // Add top selling categories summary for the dashboard (e.g., top 5)
    // Assuming statistics.getTopSellingCategories() returns [{ category, sales }]
    const topCategories = statistics.getTopSellingCategories(5);

    res.json({
      totalRevenue,
      totalOrders,
      totalProductsSold,
      lowStockProducts,
      monthlyRevenue,
      topCategories, // new field added
    });
  } catch (error) {
    console.error('Error loading dashboard stats:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Inventory routes
router.get('/admin/inventory', checkAdmin, async (req, res) => {
  try {
    const products = await inventory.getAllProducts();
    res.json(products);
  } catch (error) {
    console.error('Error getting inventory:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/admin/inventory', checkAdmin, async (req, res) => {
  try {
    const productData = req.body;
    const newProduct = await inventory.addProduct(productData);
    res.status(201).json(newProduct);
  } catch (error) {
    console.error('Error adding product:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.put('/admin/inventory/:id', checkAdmin, async (req, res) => {
  try {
    const id = req.params.id;
    const updateData = req.body;
    const updatedProduct = await inventory.updateProduct(id, updateData);
    if (!updatedProduct) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json(updatedProduct);
  } catch (error) {
    console.error('Error updating product:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.delete('/admin/inventory/:id', checkAdmin, async (req, res) => {
  try {
    const id = req.params.id;
    const success = await inventory.deleteProduct(id);
    if (!success) {
      return res.status(404).json({ error: 'Product not found' });
    }
    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    console.error('Error deleting product:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// User management routes
router.get('/admin/users', checkAdmin, async (req, res) => {
  try {
    const users = await admin.getAllUsers();
    res.json(users);
  } catch (error) {
    console.error('Error getting users:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.patch('/admin/users/:id/role', checkAdmin, async (req, res) => {
  try {
    const id = req.params.id;
    const { role } = req.body;
    const updatedUser = await admin.updateUserRole(id, role);
    if (!updatedUser) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(updatedUser);
  } catch (error) {
    console.error('Error updating user role:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Order management routes
router.get('/admin/orders', checkAdmin, async (req, res) => {
  try {
    const orders = await admin.getAllOrders();
    res.json(orders);
  } catch (error) {
    console.error('Error getting orders:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.patch('/admin/orders/:id/status', checkAdmin, async (req, res) => {
  try {
    const id = req.params.id;
    const { status } = req.body;
    const updatedOrder = await admin.updateOrderStatus(id, status);
    if (!updatedOrder) {
      return res.status(404).json({ error: 'Order not found' });
    }
    res.json(updatedOrder);
  } catch (error) {
    console.error('Error updating order status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Reports route with top categories support
router.get('/admin/reports/:type', checkAdmin, async (req, res) => {
  try {
    const { type } = req.params;
    const { startDate, endDate } = req.query;

    await statistics.loadData();

    let report = null;

    switch (type) {
      case 'sales':
        report = statistics.getSalesReport(startDate, endDate);
        break;
      case 'products':
        report = statistics.getProductSalesReport(startDate, endDate);
        break;
      case 'users':
        report = statistics.getUserOrderReport(startDate, endDate);
        break;
      default:
        return res.status(400).json({ error: 'Invalid report type' });
    }

    res.json(report);
  } catch (error) {
    console.error('Error generating report:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// New route to fetch top selling categories optionally filtered by date range
router.get('/admin/reports/top-categories', checkAdmin, async (req, res) => {
  try {
    const { startDate, endDate, limit } = req.query;
    await statistics.loadData();

    // Assume getTopSellingCategories(startDate, endDate, limit) exists in Statistics
    const topCategories = statistics.getTopSellingCategories(
      limit ? parseInt(limit) : 5,
      startDate,
      endDate
    );

    res.json({ topCategories });
  } catch (error) {
    console.error('Error fetching top categories:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router;
