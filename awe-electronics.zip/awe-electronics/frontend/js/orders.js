// DOM Elements
const ordersList = document.getElementById("ordersList");
const statusFilter = document.getElementById("statusFilter");
const orderSearch = document.getElementById("orderSearch");
const orderModal = document.getElementById("orderModal");
const orderDetails = document.getElementById("orderDetails");
const modalCloseBtn = orderModal.querySelector(".close");

let orders = []; // Will hold orders (using fake data now)

// Helper: Format date nicely
function formatDate(dateStr) {
  const options = { year: "numeric", month: "short", day: "numeric", hour: '2-digit', minute: '2-digit' };
  return new Date(dateStr).toLocaleDateString(undefined, options);
}

// Render orders list based on filters
function renderOrders() {
  const filterStatus = statusFilter.value.toLowerCase();
  const searchTerm = orderSearch.value.toLowerCase();

  // Filter and search orders
  const filteredOrders = orders.filter(order => {
    const statusMatch = filterStatus === "all" || order.status.toLowerCase() === filterStatus;
    const searchMatch =
      order.orderId.toLowerCase().includes(searchTerm) ||
      order.user.firstName.toLowerCase().includes(searchTerm) ||
      order.user.lastName.toLowerCase().includes(searchTerm) ||
      order.user.email.toLowerCase().includes(searchTerm);
    return statusMatch && searchMatch;
  });

  // Clear previous list
  ordersList.innerHTML = "";

  if (filteredOrders.length === 0) {
    ordersList.innerHTML = "<p>No orders found.</p>";
    return;
  }

  // Build order items
  filteredOrders.forEach(order => {
    const orderDiv = document.createElement("div");
    orderDiv.classList.add("order-item");
    orderDiv.tabIndex = 0; // for accessibility
    orderDiv.setAttribute("role", "button");
    orderDiv.setAttribute("aria-pressed", "false");

    orderDiv.innerHTML = `
      <div class="order-summary">
        <strong>Order ID:</strong>${order.orderId}<br> Click for Details <br>
      </div>
    `;

    orderDiv.addEventListener("click", () => showOrderDetails(order));
    orderDiv.addEventListener("keydown", e => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        showOrderDetails(order);
      }
    });

    ordersList.appendChild(orderDiv);
  });
}

// Show modal with order details
function showOrderDetails(order) {
  orderDetails.innerHTML = `
    <h2>Order Details: ${order.orderId}</h2>
    <p><strong>Date:</strong> ${formatDate(order.date)}</p>
    <p><strong>Status:</strong> ${order.status}</p>

    <h3>Customer Info</h3>
    <p>
      ${order.user.firstName} ${order.user.lastName}<br>
      Email: ${order.user.email}<br>
      Address: ${order.user.address.street}, ${order.user.address.city}, ${order.user.address.state} ${order.user.address.zip}
    </p>
  `;

  orderModal.style.display = "block";
  orderModal.setAttribute("aria-hidden", "false");
}

// Close modal function
function closeModal() {
  orderModal.style.display = "none";
  orderModal.setAttribute("aria-hidden", "true");
}

// Event listeners
statusFilter.addEventListener("change", renderOrders);
orderSearch.addEventListener("input", renderOrders);
modalCloseBtn.addEventListener("click", closeModal);
window.addEventListener("click", (e) => {
  if (e.target === orderModal) {
    closeModal();
  }
});

// Load fake orders (no backend fetch)
function fetchOrdersForUser() {
  orders = [
    {
      orderId: "ORD1001",
      date: "2025-06-05T14:30:00Z",
      status: "Processing",
      user: {
        firstName: "John",
        lastName: "Doe",
        email: "john.doe@example.com",
        address: {
          street: "123 Main St",
          city: "Melbourne",
          state: "VIC",
          zip: "3000"
        }
      },
      items: [
        { name: "Dell XPS 13", quantity: 1, price: 1499.00 },
        { name: "Wireless Mouse", quantity: 2, price: 29.99 }
      ],
      total: 1499.00 + 2 * 29.99
    },
    {
      orderId: "ORD1002",
      date: "2025-06-01T10:15:00Z",
      status: "Shipped",
      user: {
        firstName: "John",
        lastName: "Doe",
        email: "john.doe@example.com",
        address: {
          street: "123 Main St",
          city: "Melbourne",
          state: "VIC",
          zip: "3000"
        }
      },
      items: [
        { name: "Apple iPhone 14", quantity: 1, price: 999.99 }
      ],
      total: 999.99
    }
  ];

  renderOrders();
}

// Initialize
fetchOrdersForUser();

