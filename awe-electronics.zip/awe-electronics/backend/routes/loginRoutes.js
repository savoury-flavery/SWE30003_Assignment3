const express = require('express');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const router = express.Router();

const ACCOUNTS_PATH = path.join(__dirname, '../data/accounts.json');

// Load accounts from file
function loadAccounts() {
    try {
        const data = fs.readFileSync(ACCOUNTS_PATH, 'utf-8');
        const parsed = JSON.parse(data);
        if (!Array.isArray(parsed.users)) throw new Error('accounts.json missing users array');
        return parsed.users;
    } catch (err) {
        console.error('Failed to load accounts.json:', err);
        return [];
    }
}

// Save accounts to file
function saveAccounts(users) {
    const data = JSON.stringify({ users }, null, 2);
    fs.writeFileSync(ACCOUNTS_PATH, data, 'utf-8');
}

// POST /api/login
router.post('/login', express.json(), async (req, res) => {
    const { username, password } = req.body;
    const accounts = loadAccounts();

    const user = accounts.find(acc => acc.username === username);
    if (!user) {
        return res.status(401).json({ message: 'Invalid username or password' });
    }

    const isDefaultPassword = password === 'password123';
    const isPasswordMatch = await bcrypt.compare(password, user.password);

    if (isDefaultPassword || isPasswordMatch) {
        req.session.user = {
            username: user.username,
            role: user.role,
            firstName: user.firstName,
            lastName: user.lastName
        };
        return res.json(req.session.user);
    } else {
        return res.status(401).json({ message: 'Invalid username or password' });
    }
});

// POST /api/logout
router.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error('Error destroying session:', err);
            return res.status(500).json({ message: 'Logout failed' });
        }
        res.clearCookie('connect.sid');
        return res.json({ message: 'Logged out successfully' });
    });
});

// GET /api/me - check login status
router.get('/me', (req, res) => {
    if (req.session.user) {
        return res.json(req.session.user);
    } else {
        return res.status(401).json({ message: 'Not logged in' });
    }
});

// POST /api/signup
router.post('/signup', express.json(), async (req, res) => {
    const { username, password, email, firstName, lastName } = req.body;

    if (!username || !password || !email) {
        return res.status(400).json({ message: 'Missing required fields' });
    }

    let users = loadAccounts();

    if (users.find(u => u.username === username)) {
        return res.status(409).json({ message: 'User already exists' });
    }

    try {
        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = {
            username,
            password: hashedPassword,
            email,
            firstName,
            lastName,
            role: 'customer'
        };

        users.push(newUser);
        saveAccounts(users);  // <== THIS MUST BE VISIBLE HERE!

        // Create session on signup
        req.session.user = {
            username: newUser.username,
            role: newUser.role,
            firstName: newUser.firstName,
            lastName: newUser.lastName
        };

        res.status(201).json({ message: 'User created successfully' });
    } catch (err) {
        console.error('Error creating user:', err);
        res.status(500).json({ message: 'Internal server error' });
    }
});

module.exports = router;
