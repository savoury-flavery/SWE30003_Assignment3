const express = require('express');
const router = express.Router();
const fs = require('fs').promises;
const path = require('path');

const cartsPath = path.join(__dirname, '../data/carts.json');

// Read all carts from file
async function readCarts() {
  try {
    const data = await fs.readFile(cartsPath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Failed to read carts:', error);
    return {};
  }
}

// Write all carts to file
async function writeCarts(carts) {
  try {
    await fs.writeFile(cartsPath, JSON.stringify(carts, null, 2));
  } catch (error) {
    console.error('Failed to write carts:', error);
  }
}

// Middleware to simulate logged-in user, or get userId from session/auth token
function getUserId(req) {
  // For example, from session or auth token
  return req.user?.id || 'guest'; // fallback to guest
}

// GET /api/cart — Get current user's cart
router.get('/cart', async (req, res) => {
  const userId = getUserId(req);
  try {
    const carts = await readCarts();
    const userCart = carts[userId] || [];
    res.json({ items: userCart });
  } catch (error) {
    console.error('Error getting cart:', error);
    res.status(500).json({ error: 'Failed to get cart' });
  }
});

// POST /api/cart — Replace or update current user's cart
router.post('/cart', async (req, res) => {
  const userId = getUserId(req);
  const { items } = req.body;

  if (!Array.isArray(items)) {
    return res.status(400).json({ error: 'Invalid cart items' });
  }

  try {
    const carts = await readCarts();
    carts[userId] = items;  
    await writeCarts(carts);
    res.status(200).json({ message: 'Cart saved' });
  } catch (error) {
    console.error('Failed to save cart:', error);
    res.status(500).json({ error: 'Failed to save cart' });
  }
});

module.exports = router;
