window.customerModule = {
  loadCustomerDetails: async function(userId) {
    try {
      const res = await fetch(`/api/accounts/${userId}`);
      if (!res.ok) throw new Error('Failed to fetch customer details');
      const customer = await res.json();

      const container = document.getElementById('customerContent');
      container.innerHTML = `
        <p><strong>Name:</strong> ${accounts.name}</p>
        <p><strong>Email:</strong> ${accounts.email}</p>
        <p><strong>Orders:</strong> ${accounts.orders.length}</p>
      `;
    } catch (error) {
      console.error(error);
      document.getElementById('customerContent').textContent = 'Failed to load customer details.';
    }
  }
};
