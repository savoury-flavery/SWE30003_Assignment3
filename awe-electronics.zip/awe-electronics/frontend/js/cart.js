class Cart {
    constructor() {
        this.items = [];
        this.loadFromStorage();
    }

    async loadFromStorage() {
        try {
            const response = await fetch('/api/cart');
            if (!response.ok) throw new Error('Failed to load cart');
            const data = await response.json();
            this.items = data.items || [];
            this.updateCartBadge();
            
            // If we're on the cart page, render the items
            if (window.location.pathname.includes('cart.html')) {
                this.renderCartItems();
            }
        } catch (error) {
            console.error('Error loading cart:', error);
            this.items = [];
        }
    }

    async addItem(product, quantity = 1) {
        try {
            const response = await fetch('/api/cart/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    productId: product.id,
                    name: product.name,
                    price: product.price,
                    image: product.image
                })
            });

            if (!response.ok) throw new Error('Failed to add item to cart');
            
            const data = await response.json();
            this.items = data.cart;
            this.updateCartBadge();
            console.log('Item added to cart:', product.name);
        } catch (error) {
            console.error('Error adding item to cart:', error);
            throw error;
        }
    }

    async removeItem(productId) {
        try {
            const response = await fetch(`/api/cart/remove/${productId}`, {
                method: 'DELETE'
            });

            if (!response.ok) throw new Error('Failed to remove item from cart');
            
            const data = await response.json();
            this.items = data.cart;
            this.updateCartBadge();
            this.renderCartItems();
        } catch (error) {
            console.error('Error removing item from cart:', error);
            throw error;
        }
    }

    async updateQuantity(productId, quantity) {
        try {
            const response = await fetch(`/api/cart/update/${productId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ quantity })
            });

            if (!response.ok) throw new Error('Failed to update cart');
            
            const data = await response.json();
            this.items = data.cart;
            this.updateCartBadge();
            this.renderCartItems();
        } catch (error) {
            console.error('Error updating cart:', error);
            throw error;
        }
    }

    getTotalItems() {
        return this.items.reduce((total, item) => total + item.quantity, 0);
    }

    getTotalPrice() {
        return this.items.reduce((total, item) => total + (item.price * item.quantity), 0);
    }

    updateCartBadge() {
        const cartBadge = document.querySelector('.cart-badge');
        if (cartBadge) {
            cartBadge.textContent = this.getTotalItems();
        }
    }

    renderCartItems() {
        const cartItemsContainer = document.getElementById('cartItems');
        if (!cartItemsContainer) return;

        // Update totals first
        const subtotal = this.getTotalPrice();
        const shipping = subtotal > 0 ? 10 : 0; // Example shipping cost
        const total = subtotal + shipping;

        document.getElementById('subtotal').textContent = `$${subtotal.toFixed(2)}`;
        document.getElementById('shipping').textContent = `$${shipping.toFixed(2)}`;
        document.getElementById('total').textContent = `$${total.toFixed(2)}`;

        if (!this.items || this.items.length === 0) {
            cartItemsContainer.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
            return;
        }

        cartItemsContainer.innerHTML = this.items.map(item => `
            <div class="cart-item" data-product-id="${item.productId}">
                <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                <div class="cart-item-details">
                    <h3>${item.name}</h3>
                    <p class="cart-item-price">$${item.price.toFixed(2)}</p>
                    <div class="quantity-controls">
                        <button class="quantity-btn minus">-</button>
                        <span class="quantity">${item.quantity}</span>
                        <button class="quantity-btn plus">+</button>
                    </div>
                </div>
                <button class="remove-item-btn">×</button>
            </div>
        `).join('');

        // Add event listeners
        this.addCartEventListeners();
    }

    addCartEventListeners() {
        const cartItemsContainer = document.getElementById('cartItems');
        if (!cartItemsContainer) return;

        cartItemsContainer.addEventListener('click', async (e) => {
            const cartItem = e.target.closest('.cart-item');
            if (!cartItem) return;

            const productId = cartItem.dataset.productId;

            if (e.target.classList.contains('remove-item-btn')) {
                await this.removeItem(productId);
            } else if (e.target.classList.contains('quantity-btn')) {
                const quantityElement = cartItem.querySelector('.quantity');
                let quantity = parseInt(quantityElement.textContent);

                if (e.target.classList.contains('minus')) {
                    quantity = Math.max(1, quantity - 1);
                } else if (e.target.classList.contains('plus')) {
                    quantity += 1;
                }

                await this.updateQuantity(productId, quantity);
            }
        });
    }
}

// Initialize cart when the page loads
document.addEventListener('DOMContentLoaded', () => {
    window.cart = new Cart();
});