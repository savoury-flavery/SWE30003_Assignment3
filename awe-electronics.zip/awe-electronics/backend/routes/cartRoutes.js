const express = require('express');
const router = express.Router();
const fs = require('fs').promises;
const path = require('path');

const cartsPath = path.join(__dirname, '../data/carts.json');

// Read all carts from file
async function readCarts() {
  try {
    const data = await fs.readFile(cartsPath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('Failed to read carts:', error);
    return {};
  }
}

// Write all carts to file
async function writeCarts(carts) {
  try {
    await fs.writeFile(cartsPath, JSON.stringify(carts, null, 2));
  } catch (error) {
    console.error('Failed to write carts:', error);
  }
}

// Middleware to simulate logged-in user, or get userId from session/auth token
function getUserId(req) {
  // For demo purposes, use a default user ID
  // In production, this would come from the session or auth token
  return 'user1';
}

// Get cart items
router.get('/cart', async (req, res) => {
  try {
    const userId = getUserId(req);
    const carts = await readCarts();
    const userCart = carts[userId] || [];
    res.json({ items: userCart });
  } catch (error) {
    console.error('Error getting cart:', error);
    res.status(500).json({ error: 'Failed to get cart', items: [] });
  }
});

// Add item to cart
router.post('/cart/add', async (req, res) => {
  const userId = getUserId(req);
  const { productId, name, price, image } = req.body;

  if (!productId) {
    return res.status(400).json({ error: 'productId is required' });
  }

  try {
    const carts = await readCarts();
    const userCart = carts[userId] || [];

    const existingItem = userCart.find(item => item.productId === productId);

    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      userCart.push({
        productId,
        name,
        price,
        image,
        quantity: 1
      });
    }

    carts[userId] = userCart;
    await writeCarts(carts);

    res.status(200).json({ message: 'Product added to cart', cart: userCart });
  } catch (error) {
    console.error('Failed to add product to cart:', error);
    res.status(500).json({ error: 'Failed to add product to cart' });
  }
});

// Remove item from cart
router.delete('/cart/remove/:productId', async (req, res) => {
  const userId = getUserId(req);
  const { productId } = req.params;

  try {
    const carts = await readCarts();
    const userCart = carts[userId] || [];

    const updatedCart = userCart.filter(item => item.productId !== productId);
    carts[userId] = updatedCart;
    await writeCarts(carts);

    res.status(200).json({ message: 'Product removed from cart', cart: updatedCart });
  } catch (error) {
    console.error('Failed to remove product from cart:', error);
    res.status(500).json({ error: 'Failed to remove product from cart' });
  }
});

// Update cart item quantity
router.put('/cart/update/:productId', async (req, res) => {
  const userId = getUserId(req);
  const { productId } = req.params;
  const { quantity } = req.body;

  if (quantity < 1) {
    return res.status(400).json({ error: 'Quantity must be at least 1' });
  }

  try {
    const carts = await readCarts();
    const userCart = carts[userId] || [];

    const item = userCart.find(item => item.productId === productId);
    if (!item) {
      return res.status(404).json({ error: 'Product not found in cart' });
    }

    item.quantity = quantity;
    carts[userId] = userCart;
    await writeCarts(carts);

    res.status(200).json({ message: 'Cart updated', cart: userCart });
  } catch (error) {
    console.error('Failed to update cart:', error);
    res.status(500).json({ error: 'Failed to update cart' });
  }
});

module.exports = router;
