class ShoppingCart {
    constructor() {
        this.items = [];
        this.shippingCost = 10;
        
        // DOM Elements
        this.cartItems = document.getElementById('cartItems');
        this.subtotalElement = document.getElementById('subtotal');
        this.shippingElement = document.getElementById('shipping');
        this.totalElement = document.getElementById('total');
        this.checkoutBtn = document.getElementById('checkoutBtn');
        
        // Initialize cart
        this.init();
    }
    
    async init() {
        await this.loadCart();
        this.addEventListeners();
        this.renderCart();
        this.updateCartBadge();
    }
    
    async loadCart() {
        try {
            const response = await fetch('/api/auth/check');
            const { isLoggedIn } = await response.json();
            
            if (isLoggedIn) {
                const cartResponse = await fetch('/api/cart');
                if (cartResponse.ok) {
                    const cartData = await cartResponse.json();
                    this.items = cartData.items || [];
                } else {
                    this.items = [];
                }
            } else {
                const savedCart = localStorage.getItem('cart');
                this.items = savedCart ? JSON.parse(savedCart) : [];
            }
        } catch (error) {
            console.error('Error loading cart:', error);
            const savedCart = localStorage.getItem('cart');
            this.items = savedCart ? JSON.parse(savedCart) : [];
        }
    }
    
    addEventListeners() {
        this.checkoutBtn.addEventListener('click', () => this.handleCheckout());
    }
    
    async addItem(product, quantity = 1) {
        console.log('Adding to cart:', product, quantity);
        const existingItem = this.items.find(item => item.id === product.id);
        if (existingItem) {
            existingItem.quantity += quantity;
            console.log('Updated quantity:', existingItem.quantity);
        } else {
            this.items.push({
                id: product.id,
                name: product.name,
                price: product.price,
                image: product.image,
                quantity
            });
            console.log('Added new item:', product.name);
        }
        await this.saveCart();
        this.renderCart();
        this.updateCartBadge();
    }

    async removeItem(productId) {
        this.items = this.items.filter(item => item.id !== productId);
        await this.saveCart();
        this.renderCart();
        this.updateCartBadge();
    }
    
    async updateQuantity(productId, quantity) {
        const item = this.items.find(item => item.id === productId);
        if (item) {
            item.quantity = Math.max(1, Number(quantity));
            await this.saveCart();
            this.renderCart();
            this.updateCartBadge();
        }
    }
    
    async saveCart() {
        try {
            const response = await fetch('/api/auth/check');
            const { isLoggedIn } = await response.json();
            
            if (isLoggedIn) {
                await fetch('/api/cart', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ items: this.items })
                });
            } else {
                localStorage.setItem('cart', JSON.stringify(this.items));
            }
        } catch (error) {
            console.error('Error saving cart:', error);
            localStorage.setItem('cart', JSON.stringify(this.items));
        }
    }
    
    calculateTotals() {
        const subtotal = this.items.reduce((total, item) => total + item.price * item.quantity, 0);
        const shipping = this.items.length > 0 ? this.shippingCost : 0;
        const total = subtotal + shipping;
        return {
            subtotal: subtotal.toFixed(2),
            shipping: shipping.toFixed(2),
            total: total.toFixed(2)
        };
    }
    
    renderCart() {
        if (this.items.length === 0) {
            this.cartItems.innerHTML = '<p class="empty-cart">Your cart is empty</p>';
            this.checkoutBtn.disabled = true;
        } else {
            this.cartItems.innerHTML = this.items.map(item => this.createCartItemHTML(item)).join('');
            this.checkoutBtn.disabled = false;
        }
        
        const totals = this.calculateTotals();
        this.subtotalElement.textContent = `$${totals.subtotal}`;
        this.shippingElement.textContent = `$${totals.shipping}`;
        this.totalElement.textContent = `$${totals.total}`;
    }
    
    createCartItemHTML(item) {
        return `
            <div class="cart-item" data-id="${item.id}">
                <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                <div class="cart-item-info">
                    <h3>${item.name}</h3>
                    <p>$${item.price.toFixed(2)} each</p>
                </div>
                <div class="cart-item-quantity">
                    <button class="quantity-btn" onclick="cart.updateQuantity('${item.id}', ${item.quantity - 1})">-</button>
                    <input type="number" class="quantity-input" value="${item.quantity}" 
                           onchange="cart.updateQuantity('${item.id}', this.value)">
                    <button class="quantity-btn" onclick="cart.updateQuantity('${item.id}', ${item.quantity + 1})">+</button>
                </div>
                <div class="cart-item-price">
                    $${(item.price * item.quantity).toFixed(2)}
                </div>
                <button class="remove-item" onclick="cart.removeItem('${item.id}')">&times;</button>
            </div>
        `;
    }
    
    updateCartBadge() {
        const cartBadge = document.querySelector('.cart-badge');
        if (cartBadge) {
            const totalItems = this.items.reduce((total, item) => total + item.quantity, 0);
            cartBadge.setAttribute('data-count', totalItems);
        }
    }
    
    async handleCheckout() {
        try {
            const response = await fetch('/api/auth/check');
            const { isLoggedIn } = await response.json();
            
            if (!isLoggedIn) {
                window.location.href = '/login.html?redirect=cart';
                return;
            }
            
            const checkoutResponse = await fetch('/api/checkout', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ items: this.items })
            });
            
            if (checkoutResponse.ok) {
                this.items = [];
                await this.saveCart();
                this.renderCart();
                this.updateCartBadge();
                window.location.href = '/order-confirmation.html';
            } else {
                alert('Error processing checkout. Please try again.');
            }
        } catch (error) {
            console.error('Error during checkout:', error);
            alert('Error processing checkout. Please try again.');
        }
    }
}

// Initialize cart globally for inline calls in HTML
const cart = new ShoppingCart();
