const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();
const productsFilePath = path.join(__dirname, 'data', 'products.json');

// Helper: Read products JSON file
function readProducts() {
  const data = fs.readFileSync(productsFilePath, 'utf-8');
  return JSON.parse(data);
}

// Helper: Write products JSON file
function writeProducts(products) {
  fs.writeFileSync(productsFilePath, JSON.stringify(products, null, 2), 'utf-8');
}

// GET all inventory
router.get('/', (req, res) => {
  try {
    const products = readProducts();
    res.json(products);
  } catch (err) {
    console.error('Error reading products:', err);
    res.status(500).json({ error: 'Failed to load inventory' });
  }
});

// PUT update stock for a product by ID
router.put('/:id/stock', (req, res) => {
  const productId = req.params.id;
  const newStock = req.body.stock;

  if (typeof newStock !== 'number' || newStock < 0) {
    return res.status(400).json({ error: 'Invalid stock value' });
  }

  try {
    const products = readProducts();
    const product = products.find(p => p.id === productId);

    if (!product) {
      return res.status(404).json({ error: 'Product not found' });
    }

    product.stock = newStock;
    writeProducts(products);

    res.json({ message: 'Stock updated', product });
  } catch (err) {
    console.error('Error updating stock:', err);
    res.status(500).json({ error: 'Failed to update stock' });
  }
});

module.exports = router;
