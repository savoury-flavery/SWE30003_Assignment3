class Product {
  constructor(data) {
    Object.assign(this, data); // id, name, category, price, description, image, isNew, specifications, stock
  }

  renderCard(onView, onAddToCart) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
      <img src="${this.image}" alt="${this.name}">
      <h3>${this.name}</h3>
      <p><strong>$${this.price.toFixed(2)}</strong></p>
      ${this.isNew ? '<span class="new-badge">NEW</span>' : ''}
      <button>Add to Cart</button>
    `;

    card.querySelector('img').addEventListener('click', () => onView(this));
    card.querySelector('button').addEventListener('click', () => onAddToCart(this));

    return card;
  }

  renderDetail(onBack, onAddToCart) {
    const view = document.createElement('div');
    view.className = 'product-detail';
    view.innerHTML = `
      <img src="${this.image}" alt="${this.name}">
      <h2>${this.name}</h2>
      <p><strong>Price:</strong> $${this.price.toFixed(2)}</p>
      <p><strong>Description:</strong> ${this.description}</p>
      <p><strong>Stock:</strong> ${this.stock > 0 ? this.stock : 'Out of Stock'}</p>
      ${this.renderSpecifications()}
      <button ${this.stock === 0 ? 'disabled' : ''}>Add to Cart</button>
      <button>Back to Catalogue</button>
    `;

    const buttons = view.querySelectorAll('button');
    buttons[0].addEventListener('click', () => onAddToCart(this));
    buttons[1].addEventListener('click', onBack);

    return view;
  }

  renderSpecifications() {
    if (!this.specifications || Object.keys(this.specifications).length === 0) return '';

    let specList = '<ul>';
    for (const [key, value] of Object.entries(this.specifications)) {
      specList += `<li><strong>${key}:</strong> ${value}</li>`;
    }
    specList += '</ul>';

    return `<div><strong>Specifications:</strong>${specList}</div>`;
  }
}

class Catalogue {
  constructor(containerId, singleViewId, filtersId, cartInstance) {
    this.container = document.getElementById(containerId);
    this.singleView = document.getElementById(singleViewId);
    this.filters = document.getElementById(filtersId);
    this.cart = cartInstance;
    this.products = [];
    this.currentPage = 1;
    this.itemsPerPage = 6;
    this.filteredProducts = [];
  }


async loadProducts() {
    try {
        const res = await fetch('/products');
        const data = await res.json();
        this.products = data.map(p => new Product(p));
        this.render();
    } catch (err) {
        console.error('Failed to load products:', err);
    }
}

render(products = this.products) {
  this.filteredProducts = products;
  const start = (this.currentPage - 1) * this.itemsPerPage;
  const end = start + this.itemsPerPage;
  const paginated = products.slice(start, end);

  this.container.innerHTML = '';
  this.container.style.display = 'flex';
  this.singleView.style.display = 'none';
  this.filters.style.display = 'block';

  paginated.forEach(product => {
    this.container.appendChild(product.renderCard(
      this.viewProduct.bind(this),
      this.cart.addToCart.bind(this.cart)
    ));
  });

  this.updatePaginationControls();
}


renderPaginationControls(totalItems) {
  const totalPages = Math.ceil(totalItems / this.itemsPerPage);
  const pagination = document.getElementById('pagination');
  pagination.innerHTML = '';

  for (let i = 1; i <= totalPages; i++) {
    const btn = document.createElement('button');
    btn.textContent = i;
    if (i === this.currentPage) btn.disabled = true;

    btn.addEventListener('click', () => {
      this.currentPage = i;
      this.render();
    });

    pagination.appendChild(btn);
  }
}

  viewProduct(product) {
    this.singleView.innerHTML = '';
      this.singleView.appendChild(product.renderDetail(
        () => this.render(this.products),
        this.addToCart.bind(this)
      ));
    this.singleView.style.display = 'flex';
    this.container.style.display = 'none';
    this.filters.style.display = 'none';
  }

  filter(category) {
    if (category === 'all') return this.render(this.products);
    if (category === 'new') return this.render(this.products.filter(p => p.isNew));
    this.render(this.products.filter(p => p.category === category));
  }
}