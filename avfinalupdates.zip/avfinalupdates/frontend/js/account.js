window.customerModule = {
  // Fake customer data
  customer: {
    firstName: "Software",
    lastName: "Architecture",
    email: "ismyfaveclass@example.com",
    phone: "0400 000 000",
    address: {
      street: "10 Rode Road",
      city: "Brisbane",
      state: "QLD",
      zip: "4069"
    }
  },

  loadCustomerDetails: function() {
    const customer = this.customer;

    const container = document.getElementById('customerContent');
    container.innerHTML = `
      <p><strong>Name:</strong> ${customer.firstName} ${customer.lastName}</p>
      <p><strong>Email:</strong> ${customer.email}</p>
      <p><strong>Phone:</strong> ${customer.phone || 'N/A'}</p>
      <p><strong>Address:</strong> ${
        customer.address
          ? `${customer.address.street}, ${customer.address.city}, ${customer.address.state} ${customer.address.zip}`
          : 'N/A'
      }</p>
    `;

    // Show the customer view section
    document.getElementById('customerView').style.display = 'block';
  }
};

// Load details when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  window.customerModule.loadCustomerDetails();
});
