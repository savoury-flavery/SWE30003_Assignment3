const express = require('express');
const router = express.Router();
const fs = require('fs').promises;
const path = require('path');
const { v4: uuidv4 } = require('uuid');

// Helper function to read orders data
async function getOrders() {
    try {
        const data = await fs.readFile(path.join(__dirname, '../data/orders.json'), 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading orders:', error);
        return { orders: [] };
    }
}

// Helper function to write orders data
async function saveOrders(orders) {
    try {
        await fs.writeFile(
            path.join(__dirname, '../data/orders.json'),
            JSON.stringify(orders, null, 2)
        );
    } catch (error) {
        console.error('Error saving orders:', error);
        throw error;
    }
}

// Get all orders for a user
router.get('/orders', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }

        const orders = await getOrders();
        const userOrders = orders.orders.filter(order => order.userId === req.session.userId);
        
        res.json(userOrders);
    } catch (error) {
        console.error('Error getting orders:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Get a specific order
router.get('/orders/:orderId', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }

        const orders = await getOrders();
        const order = orders.orders.find(
            order => order.id === req.params.orderId && order.userId === req.session.userId
        );

        if (!order) {
            return res.status(404).json({ error: 'Order not found' });
        }

        res.json(order);
    } catch (error) {
        console.error('Error getting order:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Create a new order
router.post('/orders', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }

        const { items, shippingAddress, paymentMethod } = req.body;
        
        // Validate required fields
        if (!items || !shippingAddress || !paymentMethod) {
            return res.status(400).json({ error: 'Missing required fields' });
        }

        const orders = await getOrders();
        
        // Calculate order totals
        const subtotal = items.reduce((total, item) => total + (item.price * item.quantity), 0);
        const shipping = 10.00; // Fixed shipping cost
        const tax = subtotal * 0.1; // 10% tax
        const total = subtotal + shipping + tax;

        // Create new order
        const newOrder = {
            id: uuidv4(),
            userId: req.session.userId,
            date: new Date().toISOString(),
            status: 'pending',
            items,
            shippingAddress,
            paymentMethod,
            subtotal,
            shipping,
            tax,
            total
        };

        orders.orders.push(newOrder);
        await saveOrders(orders);

        // Send order confirmation email (to be implemented)
        // await sendOrderConfirmationEmail(newOrder);

        res.status(201).json(newOrder);
    } catch (error) {
        console.error('Error creating order:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Update order status
router.patch('/orders/:orderId/status', async (req, res) => {
    try {
        if (!req.session.userId) {
            return res.status(401).json({ error: 'User not authenticated' });
        }

        const { status } = req.body;
        const validStatuses = ['pending', 'processing', 'shipped', 'delivered'];
        
        if (!validStatuses.includes(status)) {
            return res.status(400).json({ error: 'Invalid status' });
        }

        const orders = await getOrders();
        const orderIndex = orders.orders.findIndex(
            order => order.id === req.params.orderId && order.userId === req.session.userId
        );

        if (orderIndex === -1) {
            return res.status(404).json({ error: 'Order not found' });
        }

        orders.orders[orderIndex].status = status;
        await saveOrders(orders);

        res.json(orders.orders[orderIndex]);
    } catch (error) {
        console.error('Error updating order status:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router; 