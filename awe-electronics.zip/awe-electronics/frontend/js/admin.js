document.addEventListener('DOMContentLoaded', () => {
  fetchInventory();
  fetchStats();
});

function fetchInventory() {
  fetch('/admin/inventory')
    .then(res => res.json())
    .then(products => {
      const tableBody = document.querySelector('#inventoryTable tbody');
      tableBody.innerHTML = '';

      products.forEach(product => {
        const row = document.createElement('tr');

        row.innerHTML = `
          <td>${product.sku}</td>
          <td>${product.name}</td>
          <td>${product.category}</td>
          <td><input type="number" value="${product.stocklevel}" min="0" data-sku="${product.sku}" /></td>
          <td><button onclick="updateStock(${product.sku})">Save</button></td>
        `;

        tableBody.appendChild(row);
      });
    });
}

function updateStock(sku) {
  const input = document.querySelector(`input[data-sku='${sku}']`);
  const newStock = parseInt(input.value, 10);

  fetch('/admin/update-stock', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sku, newStock }),
  }).then(res => res.json())
    .then(data => {
      alert(data.message || 'Stock updated!');
    });
}

function fetchStats() {
  fetch('/admin/stats')
    .then(res => res.json())
    .then(stats => {
      document.getElementById('totalOrders').textContent = stats.totalOrders;
      document.getElementById('totalRevenue').textContent = stats.totalRevenue.toFixed(2);
    });
}

function logout() {
  fetch('/logout', { method: 'POST' })
    .then(() => window.location.href = 'index.html');
}

class AdminDashboard {
    constructor() {
        this.currentSection = 'dashboard';
        this.products = [];
        this.orders = [];
        this.users = [];
        this.inventory = [];
        
        // Initialize charts
        this.salesChart = null;
        this.productsChart = null;
        this.reportChart = null;
        
        this.init();
    }
    
    async init() {
        // Check if user is admin
        const response = await fetch('/api/auth/check');
        const result = await response.json();
        if (!response.ok || !result.isAdmin) {
            window.location.href = '/login.html';
            return;
        }
        
        // Set up event listeners
        this.setupEventListeners();
        
        // Load initial data
        await this.loadDashboardData();
        await this.loadProducts();
        await this.loadOrders();
        await this.loadUsers();
        await this.loadInventory();
        
        // Initialize charts
        this.initializeCharts();
    }
    
    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.admin-nav-item').forEach(item => {
            item.addEventListener('click', () => this.switchSection(item.dataset.section));
        });
        
        // Product management
        document.getElementById('addProductBtn').addEventListener('click', () => this.showProductModal());
        document.getElementById('productSearch').addEventListener('input', (e) => this.filterProducts(e.target.value));
        document.getElementById('categoryFilter').addEventListener('change', (e) => this.filterProductsByCategory(e.target.value));
        document.getElementById('stockFilter').addEventListener('change', (e) => this.filterProductsByStock(e.target.value));
        
        // Order management
        document.getElementById('orderSearch').addEventListener('input', (e) => this.filterOrders(e.target.value));
        document.getElementById('orderStatusFilter').addEventListener('change', (e) => this.filterOrdersByStatus(e.target.value));
        document.getElementById('orderDateFilter').addEventListener('change', (e) => this.filterOrdersByDate(e.target.value));
        
        // User management
        document.getElementById('userSearch').addEventListener('input', (e) => this.filterUsers(e.target.value));
        document.getElementById('userRoleFilter').addEventListener('change', (e) => this.filterUsersByRole(e.target.value));
        
        // Inventory management
        document.getElementById('inventorySearch').addEventListener('input', (e) => this.filterInventory(e.target.value));
        document.getElementById('inventoryCategoryFilter').addEventListener('change', (e) => this.filterInventoryByCategory(e.target.value));
        document.getElementById('inventoryStatusFilter').addEventListener('change', (e) => this.filterInventoryByStatus(e.target.value));
        
        // Reports
        document.getElementById('generateReportBtn').addEventListener('click', () => this.generateReport());
        
        // Modal close buttons
        document.querySelectorAll('.close').forEach(button => {
            button.addEventListener('click', () => this.closeModals());
        });
    }
    
    async loadDashboardData() {
    try {
        const response = await fetch('/data/stats.json');
        if (!response.ok) throw new Error('Failed to load stats');
        const data = await response.json();

        // Populate summary cards
        document.querySelector('.stat-card:nth-child(1) .stat-value').textContent = `$${data.yearlyStats.totalSales.toFixed(2)}`;
        document.querySelector('.stat-card:nth-child(2) .stat-value').textContent = `$${data.monthlyStats.totalSales.toFixed(2)}`;
        document.querySelector('.stat-card:nth-child(3) .stat-value').textContent = `$${data.weeklyStats.totalSales.toFixed(2)}`;
        document.querySelector('.stat-card:nth-child(4) .stat-value').textContent = `Avg $${data.dailyStats.at(-1)?.totalSales.toFixed(2) || 0}`;

        // Populate sales chart with dailyStats
        const labels = data.dailyStats.map(entry => entry.date);
        const values = data.dailyStats.map(entry => entry.totalSales);

        this.updateSalesChart({ labels, values });

        // Example for category-specific data (optional stacked bar, pie, etc.)
        // You could expand this part for more charts
    } catch (error) {
        console.error('Error loading stats:', error);
        this.showError('Failed to load sales statistics.');
    }
    }

    
    async loadProducts() {
        try {
            const response = await fetch('/api/admin/products');
            if (!response.ok) throw new Error('Failed to load products');
            this.products = await response.json();
            this.renderProducts();
        } catch (error) {
            console.error('Error loading products:', error);
            this.showError('Failed to load products');
        }
    }
    
    async loadOrders() {
        try {
            const response = await fetch('/api/admin/orders');
            if (!response.ok) throw new Error('Failed to load orders');
            this.orders = await response.json();
            this.renderOrders();
        } catch (error) {
            console.error('Error loading orders:', error);
            this.showError('Failed to load orders');
        }
    }
    
    async loadUsers() {
        try {
            const response = await fetch('/api/admin/users');
            if (!response.ok) throw new Error('Failed to load users');
            this.users = await response.json();
            this.renderUsers();
        } catch (error) {
            console.error('Error loading users:', error);
            this.showError('Failed to load users');
        }
    }
    
    async loadInventory() {
        try {
            const response = await fetch('/api/admin/inventory');
            if (!response.ok) throw new Error('Failed to load inventory');
            this.inventory = await response.json();
            this.renderInventory();
        } catch (error) {
            console.error('Error loading inventory:', error);
            this.showError('Failed to load inventory');
        }
    }
    
    switchSection(section) {
        // Update navigation
        document.querySelectorAll('.admin-nav-item').forEach(item => {
            item.classList.toggle('active', item.dataset.section === section);
        });
        
        // Update sections
        document.querySelectorAll('.admin-section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(section).classList.add('active');
        
        this.currentSection = section;
    }
    
    // Product Management
    renderProducts() {
        const tbody = document.querySelector('#productsTable tbody');
        tbody.innerHTML = this.products.map(product => `
            <tr>
                <td>${product.id}</td>
                <td><img src="${product.image}" alt="${product.name}" width="50"></td>
                <td>${product.name}</td>
                <td>${product.category}</td>
                <td>$${product.price.toFixed(2)}</td>
                <td>${product.stock}</td>
                <td class="action-buttons">
                    <button class="btn-edit" onclick="adminDashboard.editProduct('${product.id}')">Edit</button>
                    <button class="btn-delete" onclick="adminDashboard.deleteProduct('${product.id}')">Delete</button>
                </td>
            </tr>
        `).join('');
    }
    
    filterProducts(query) {
        const filtered = this.products.filter(product => 
            product.name.toLowerCase().includes(query.toLowerCase()) ||
            product.category.toLowerCase().includes(query.toLowerCase())
        );
        this.renderFilteredProducts(filtered);
    }
    
    filterProductsByCategory(category) {
        const filtered = category === 'all' 
            ? this.products 
            : this.products.filter(product => product.category === category);
        this.renderFilteredProducts(filtered);
    }
    
    filterProductsByStock(status) {
        let filtered;
        switch (status) {
            case 'low':
                filtered = this.products.filter(product => product.stock < 10);
                break;
            case 'out':
                filtered = this.products.filter(product => product.stock === 0);
                break;
            default:
                filtered = this.products;
        }
        this.renderFilteredProducts(filtered);
    }
    
    renderFilteredProducts(products) {
        const tbody = document.querySelector('#productsTable tbody');
        tbody.innerHTML = products.map(product => `
            <tr>
                <td>${product.id}</td>
                <td><img src="${product.image}" alt="${product.name}" width="50"></td>
                <td>${product.name}</td>
                <td>${product.category}</td>
                <td>$${product.price.toFixed(2)}</td>
                <td>${product.stock}</td>
                <td class="action-buttons">
                    <button class="btn-edit" onclick="adminDashboard.editProduct('${product.id}')">Edit</button>
                    <button class="btn-delete" onclick="adminDashboard.deleteProduct('${product.id}')">Delete</button>
                </td>
            </tr>
        `).join('');
    }
    
    // Order Management
    renderOrders() {
        const tbody = document.querySelector('#ordersTable tbody');
        tbody.innerHTML = this.orders.map(order => `
            <tr>
                <td>${order.id}</td>
                <td>${order.customerName}</td>
                <td>${new Date(order.date).toLocaleDateString()}</td>
                <td>$${order.total.toFixed(2)}</td>
                <td><span class="order-status status-${order.status.toLowerCase()}">${order.status}</span></td>
                <td class="action-buttons">
                    <button class="btn-edit" onclick="adminDashboard.viewOrder('${order.id}')">View</button>
                    <button class="btn-edit" onclick="adminDashboard.updateOrderStatus('${order.id}')">Update Status</button>
                </td>
            </tr>
        `).join('');
    }
    
    // User Management
    renderUsers() {
        const tbody = document.querySelector('#usersTable tbody');
        tbody.innerHTML = this.users.map(user => `
            <tr>
                <td>${user.id}</td>
                <td>${user.name}</td>
                <td>${user.email}</td>
                <td>${user.role}</td>
                <td>${user.status}</td>
                <td class="action-buttons">
                    <button class="btn-edit" onclick="adminDashboard.editUser('${user.id}')">Edit</button>
                    <button class="btn-delete" onclick="adminDashboard.deleteUser('${user.id}')">Delete</button>
                </td>
            </tr>
        `).join('');
    }
    
    // Inventory Management
    renderInventory() {
        const tbody = document.querySelector('#inventoryTable tbody');
        tbody.innerHTML = this.inventory.map(item => `
            <tr>
                <td>${item.productId}</td>
                <td>${item.name}</td>
                <td>${item.category}</td>
                <td>${item.currentStock}</td>
                <td>${item.reorderLevel}</td>
                <td><span class="inventory-status status-${item.status.toLowerCase()}">${item.status}</span></td>
                <td class="action-buttons">
                    <button class="btn-edit" onclick="adminDashboard.updateStock('${item.productId}')">Update Stock</button>
                </td>
            </tr>
        `).join('');
    }
    
    // Charts
    initializeCharts() {
        // Sales Chart
        const salesCtx = document.getElementById('salesChart').getContext('2d');
        this.salesChart = new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Sales',
                    data: [],
                    borderColor: '#4CAF50',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
        
        // Products Chart
        const productsCtx = document.getElementById('productsChart').getContext('2d');
        this.productsChart = new Chart(productsCtx, {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Top Products',
                    data: [],
                    backgroundColor: '#2196F3'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
        
        // Report Chart
        const reportCtx = document.getElementById('reportChart').getContext('2d');
        this.reportChart = new Chart(reportCtx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Report Data',
                    data: [],
                    borderColor: '#9C27B0',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }
    
    updateSalesChart(data) {
        this.salesChart.data.labels = data.labels;
        this.salesChart.data.datasets[0].data = data.values;
        this.salesChart.update();
    }
    
    updateProductsChart(data) {
        this.productsChart.data.labels = data.labels;
        this.productsChart.data.datasets[0].data = data.values;
        this.productsChart.update();
    }
    
    // Report Generation
    async generateReport() {
        const type = document.getElementById('reportType').value;
        const startDate = document.getElementById('reportStartDate').value;
        const endDate = document.getElementById('reportEndDate').value;
        
        try {
            const response = await fetch(`/api/admin/reports/${type}?startDate=${startDate}&endDate=${endDate}`);
            if (!response.ok) throw new Error('Failed to generate report');
            const data = await response.json();
            
            this.updateReportChart(data);
            this.renderReportTable(data);
        } catch (error) {
            console.error('Error generating report:', error);
            this.showError('Failed to generate report');
        }
    }
    
    updateReportChart(data) {
        this.reportChart.data.labels = data.labels;
        this.reportChart.data.datasets[0].data = data.values;
        this.reportChart.update();
    }
    
    renderReportTable(data) {
        const table = document.getElementById('reportTable');
        // Implementation depends on report type
    }
    
    // Utility Functions
    showError(message) {
        // Implement error notification
        console.error(message);
    }
    
    closeModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
    }
}

// Initialize admin dashboard when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.adminDashboard = new AdminDashboard();
});
