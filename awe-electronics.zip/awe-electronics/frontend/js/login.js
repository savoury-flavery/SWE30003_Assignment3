document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');
    const signupForm = document.getElementById('signupForm');
    const showSignupLink = document.getElementById('showSignup');
    const showLoginLink = document.getElementById('showLogin');
    const loginSection = document.querySelector('.login-container');
    const signupSection = document.getElementById('signupSection');
    const messageDiv = document.getElementById('message');
    const signupMessageDiv = document.getElementById('signupMessage');

    checkLoginStatus();

    if (showSignupLink) {
        showSignupLink.addEventListener('click', (e) => {
            e.preventDefault();
            loginSection.style.display = 'none';
            signupSection.style.display = 'flex';
        });
    }

    if (showLoginLink) {
        showLoginLink.addEventListener('click', (e) => {
            e.preventDefault();
            signupSection.style.display = 'none';
            loginSection.style.display = 'flex';
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            try {
                const response = await fetch('/api/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    credentials: 'include', 
                    body: JSON.stringify({ username, password })
                });

                const data = await response.json();

                if (response.ok) {
                    messageDiv.textContent = 'Login successful! Redirecting...';
                    messageDiv.style.color = 'green';
                    updateNavbar(data);

                    if (data.role === 'admin') {
                        window.location.href = '/admin.html';
                    } else {
                        window.location.href = '/index.html';
                    }
                } else {
                    messageDiv.textContent = data.message || 'Login failed';
                    messageDiv.style.color = 'red';
                }
            } catch (error) {
                console.error('Login error:', error);
                messageDiv.textContent = 'An error occurred. Please try again.';
                messageDiv.style.color = 'red';
            }
        });
    }

    if (signupForm) {
        signupForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('signupEmail').value;
            const password = document.getElementById('signupPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;

            if (password !== confirmPassword) {
                signupMessageDiv.textContent = 'Passwords do not match';
                signupMessageDiv.style.color = 'red';
                return;
            }

            try {
                const response = await fetch('/api/signup', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        username: email,
                        password,
                        email,
                        firstName: email.split('@')[0],
                        lastName: 'User'
                    }),
                    credentials: 'include'
                });

                const data = await response.json();

                if (response.ok) {
                    signupMessageDiv.textContent = 'Account created successfully! Please login.';
                    signupMessageDiv.style.color = 'green';

                    setTimeout(() => {
                        signupSection.style.display = 'none';
                        loginSection.style.display = 'flex';
                        document.getElementById('username').value = email;
                    }, 2000);
                } else {
                    signupMessageDiv.textContent = data.message || 'Signup failed';
                    signupMessageDiv.style.color = 'red';
                }
            } catch (error) {
                console.error('Signup error:', error);
                signupMessageDiv.textContent = 'An error occurred. Please try again.';
                signupMessageDiv.style.color = 'red';
            }
        });
    }
});

// Check login status
async function checkLoginStatus() {
    try {
        const response = await fetch('/api/me', {
            credentials: 'include'  
        });
        if (response.ok) {
            const userData = await response.json();
            updateNavbar(userData);
        }
    } catch (error) {
        console.error('Error checking login status:', error);
    }
}

// Update navbar UI
function updateNavbar(userData) {
    const navLinks = document.querySelector('.nav-links');
    const loginLink = navLinks.querySelector('a[href="login.html"]').parentElement;

    const userMenu = document.createElement('li');
    userMenu.className = 'user-menu';
    userMenu.innerHTML = `
        <div class="user-info">
            <span>Welcome, ${userData.firstName}</span>
            <div class="dropdown-menu">
                <a href="/account.html">My Profile</a>
                <a href="/orders.html">My Orders</a>
                ${userData.role === 'admin' ? '<a href="/admin.html">Admin Dashboard</a>' : ''}
                <a href="#" id="logoutBtn">Logout</a>
            </div>
        </div>
    `;

    loginLink.replaceWith(userMenu);

    document.getElementById('logoutBtn').addEventListener('click', async (e) => {
        e.preventDefault();
        try {
            await fetch('/api/logout', {
                method: 'POST',
                credentials: 'include'  
            });
            window.location.href = '/index.html';
        } catch (error) {
            console.error('Logout error:', error);
        }
    });
}
