class Delivery {
  constructor(deliveryId, order, shippingAddress) {
    this.deliveryId = deliveryId;               // String
    this.order = order;                         // Order object
    this.shippingAddress = shippingAddress;   // Address object
    this.status = 'Pending';                   // DeliveryStatus (string), e.g., Pending, Shipped, Delivered, Cancelled
    this.trackingNumber = this.generateTrackingNumber();
    this.courier = null;                       // Courier object
  }

  static createDelivery(order, address) {
    const deliveryId = Delivery.generateId();
    return new Delivery(deliveryId, order, address);
  }

  updateDeliveryStatus(status) {
    this.status = status;
  }

  getTrackingInfo() {
    return {
      deliveryId: this.deliveryId,
      trackingNumber: this.trackingNumber,
      status: this.status,
      courier: this.courier ? {
        courierId: this.courier.courierId,
        name: this.courier.name,
        contact: this.courier.contact
      } : null,
      shippingAddress: this.shippingAddress
    };
  }

  assignCourier(courier) {
    this.courier = courier;
  }

  generateTrackingNumber() {
    // Simple tracking number generator — can be improved
    return 'TRK-' + Math.random().toString(36).substr(2, 9).toUpperCase();
  }

  static generateId() {
    // Simple unique ID generator
    return 'DEL-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
  }
}

class Courier {
  constructor(courierId, name, contact) {
    this.courierId = courierId; // String
    this.name = name;           // String
    this.contact = contact;     // String (phone/email)
  }

  updateDeliveryStatus(delivery, status) {
    if (delivery instanceof Delivery) {
      delivery.updateDeliveryStatus(status);
    } else {
      throw new Error('Invalid Delivery object');
    }
  }
}

module.exports = { Delivery, Courier };
