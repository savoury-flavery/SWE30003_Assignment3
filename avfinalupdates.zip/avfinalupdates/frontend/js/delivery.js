// delivery.js

class Delivery {
  constructor(deliveryId, order, shippingAddress) {
    this.deliveryId = deliveryId;
    this.order = order;
    this.shippingAddress = shippingAddress;
    this.status = 'Pending';
    this.trackingNumber = this.generateTrackingNumber();
    this.courier = null;
  }

  static createDelivery(order, address) {
    const deliveryId = Delivery.generateId();
    return new Delivery(deliveryId, order, address);
  }

  updateDeliveryStatus(status) {
    this.status = status;
    renderDeliveryDetails(this);  // Update UI on status change
  }

  getTrackingInfo() {
    return {
      deliveryId: this.deliveryId,
      trackingNumber: this.trackingNumber,
      status: this.status,
      courier: this.courier ? {
        courierId: this.courier.courierId,
        name: this.courier.name,
        contact: this.courier.contact
      } : null,
      shippingAddress: this.shippingAddress
    };
  }

  assignCourier(courier) {
    this.courier = courier;
  }

  generateTrackingNumber() {
    return 'TRK-' + Math.random().toString(36).substr(2, 9).toUpperCase();
  }

  static generateId() {
    return 'DEL-' + Date.now() + '-' + Math.floor(Math.random() * 1000);
  }
}

class Courier {
  constructor(courierId, name, contact) {
    this.courierId = courierId;
    this.name = name;
    this.contact = contact;
  }

  updateDeliveryStatus(delivery, status) {
    if (delivery instanceof Delivery) {
      delivery.updateDeliveryStatus(status);
    } else {
      throw new Error('Invalid Delivery object');
    }
  }
}
// Sample orders
const orders = [
  {
    orderId: 'ORD-001',
    items: [
      { name: 'Wireless Mouse', quantity: 1, price: 25 },
      { name: 'Mechanical Keyboard', quantity: 1, price: 75 }
    ],
    total: 100,
    shippingAddress: {
      street: '456 Elm St',
      city: 'Somewhere',
      state: 'TX',
      zip: '75001'
    }
  }
];

// Create a delivery for the first order
const delivery = Delivery.createDelivery(orders[0], orders[0].shippingAddress);

// Assign a courier
const courier = new Courier('CR-001', 'FastShip Couriers', 'contact@fastship.com');
delivery.assignCourier(courier);

function renderOrders() {
  const container = document.getElementById('ordersContent');
  container.innerHTML = orders.map(order => `
    <div>
      <strong>Order ID:</strong> ${order.orderId} <br />
      <strong>Items:</strong>
      <ul>
        ${order.items.map(i => `<li>${i.quantity} x ${i.name} ($${i.price})</li>`).join('')}
      </ul>
      <strong>Total:</strong> $${order.total.toFixed(2)}
    </div>
  `).join('');
}

function renderDeliveryDetails(delivery) {
  const container = document.getElementById('deliveryContent');
  const info = delivery.getTrackingInfo();

  container.innerHTML = `
    <p><strong>Delivery ID:</strong> ${info.deliveryId}</p>
    <p><strong>Tracking Number:</strong> ${info.trackingNumber}</p>
    <p><strong>Status:</strong> ${info.status}</p>
    <p><strong>Courier:</strong> ${info.courier ? info.courier.name + ' (' + info.courier.contact + ')' : 'Not assigned'}</p>
    <p><strong>Shipping Address:</strong> ${info.shippingAddress.street}, ${info.shippingAddress.city}, ${info.shippingAddress.state} ${info.shippingAddress.zip}</p>

    <button id="updateStatusBtn">Mark as Shipped</button>
  `;

  // Setup button event to simulate status update
  document.getElementById('updateStatusBtn').onclick = () => {
    delivery.updateDeliveryStatus('Shipped');
  };
}

// Initialize the page by rendering orders and delivery
document.addEventListener('DOMContentLoaded', () => {
  renderOrders();
  renderDeliveryDetails(delivery);
});
