const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();

router.get('/stats', (req, res) => {
  const filePath = path.join(__dirname, '../data/stats.json');
  fs.readFile(filePath, 'utf8', (err, data) => {
    if (err) {
      console.error('Failed to read stats.json:', err);
      return res.status(500).json({ error: 'Unable to load stats data' });
    }
    res.json(JSON.parse(data));
  });
});

module.exports = router;
