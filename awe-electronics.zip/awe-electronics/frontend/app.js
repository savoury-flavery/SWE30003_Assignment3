// Static fallback products data for initial load or fallback
const staticProducts = [
  {
    id: '1',
    name: 'Laptop Pro',
    price: 1200,
    category: 'laptops',
    image: 'https://via.placeholder.com/150',
    description: 'A high-performance laptop for professionals.',
    specifications: {}
  },
  {
    id: '2',
    name: 'Smartphone X',
    price: 800,
    category: 'phones',
    image: 'https://via.placeholder.com/150',
    description: 'The latest smartphone with an amazing camera.',
    specifications: {}
  },
  {
    id: '3',
    name: 'Wireless Headphones',
    price: 150,
    category: 'accessories',
    image: 'https://via.placeholder.com/150',
    description: 'Comfortable over-ear headphones with noise cancellation.',
    specifications: {}
  },
  {
    id: '4',
    name: 'Digital Camera',
    price: 600,
    category: 'cameras',
    image: 'https://via.placeholder.com/150',
    description: 'Capture stunning photos and videos.',
    specifications: {}
  },
  {
    id: '5',
    name: 'Smart Refrigerator',
    price: 2000,
    category: 'appliances',
    image: 'https://via.placeholder.com/150',
    description: 'A smart fridge with a built-in touchscreen.',
    specifications: {}
  },
];

// Simple elements
const productGrid = document.getElementById('productGrid');
const singleProductView = document.getElementById('singleProduct');

// Fallback display function using static products
function displayProducts(filteredProducts = staticProducts) {
  productGrid.innerHTML = ''; // Clear existing products
  filteredProducts.forEach((product) => {
    const productCard = document.createElement('div');
    productCard.classList.add('product-card');
    productCard.innerHTML = `
      <img src="${product.image}" alt="${product.name}">
      <h3>${product.name}</h3>
      <p>£${product.price.toFixed(2)}</p>
      <button onclick="productCatalogue.showProductDetails('${product.id}')">View Details</button>
      <button onclick="productCatalogue.addToCart('${product.id}')">Add to Cart</button>
    `;
    productGrid.appendChild(productCard);
  });
  productGrid.style.display = 'flex';
  singleProductView.style.display = 'none';
}

window.goToLogin = () => {
  window.location.href = "login.html";
};

window.goToAccount = () => {
  window.location.href = "account.html";
};

window.viewCart = () => {
  alert("Cart feature coming soon!");
};
