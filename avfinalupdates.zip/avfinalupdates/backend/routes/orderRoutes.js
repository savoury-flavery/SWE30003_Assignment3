const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();
const ordersFilePath = path.join(__dirname, '../data/orders.json');

// Helper to read orders.json
function readOrders() {
  try {
    const data = fs.readFileSync(ordersFilePath, 'utf8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

// Helper to write orders.json
function writeOrders(orders) {
  fs.writeFileSync(ordersFilePath, JSON.stringify(orders, null, 2));
}

// POST new order
router.post('/api/orders', (req, res) => {
  const newOrder = req.body;

  if (!newOrder || !newOrder.orderId) {
    return res.status(400).json({ error: 'Invalid order data' });
  }

  const orders = readOrders();
  orders.push(newOrder);
  writeOrders(orders);

  res.status(201).json({ message: 'Order saved', order: newOrder });
});

router.get('/api/orders', (req, res) => {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const orders = readOrders();
  const userOrders = orders.filter(order => order.user.email === req.session.user.email);
  res.json(userOrders);
});


module.exports = router;
