class OrderManager {
    constructor() {
        this.orders = [];
        this.filteredOrders = [];
        this.currentFilter = 'all';
        this.searchQuery = '';
        
        // DOM Elements
        this.ordersList = document.getElementById('ordersList');
        this.statusFilter = document.getElementById('statusFilter');
        this.orderSearch = document.getElementById('orderSearch');
        this.orderModal = document.getElementById('orderModal');
        this.orderDetails = document.getElementById('orderDetails');
        this.closeModal = document.querySelector('.close');
        
        this.init();
    }
    
    async init() {
        // Check if user is logged in
        const response = await fetch('/api/auth/check');
        if (!response.ok) {
            window.location.href = '/login.html';
            return;
        }
        
        // Load orders
        await this.loadOrders();
        
        // Set up event listeners
        this.setupEventListeners();
        
        // Initial render
        this.renderOrders();
    }
    
    async loadOrders() {
        try {
            const response = await fetch('/api/orders');
            if (!response.ok) throw new Error('Failed to load orders');
            this.orders = await response.json();
            this.filteredOrders = [...this.orders];
        } catch (error) {
            console.error('Error loading orders:', error);
            this.showError('Failed to load orders. Please try again later.');
        }
    }
    
    setupEventListeners() {
        // Status filter
        this.statusFilter.addEventListener('change', (e) => {
            this.currentFilter = e.target.value;
            this.filterOrders();
        });
        
        // Search
        this.orderSearch.addEventListener('input', (e) => {
            this.searchQuery = e.target.value.toLowerCase();
            this.filterOrders();
        });
        
        // Modal close
        this.closeModal.addEventListener('click', () => {
            this.orderModal.style.display = 'none';
        });
        
        // Close modal when clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === this.orderModal) {
                this.orderModal.style.display = 'none';
            }
        });
    }
    
    filterOrders() {
        this.filteredOrders = this.orders.filter(order => {
            const matchesFilter = this.currentFilter === 'all' || order.status === this.currentFilter;
            const matchesSearch = !this.searchQuery || 
                order.id.toLowerCase().includes(this.searchQuery) ||
                order.items.some(item => item.name.toLowerCase().includes(this.searchQuery));
            
            return matchesFilter && matchesSearch;
        });
        
        this.renderOrders();
    }
    
    renderOrders() {
        if (this.filteredOrders.length === 0) {
            this.ordersList.innerHTML = '<p class="no-orders">No orders found</p>';
            return;
        }
        
        this.ordersList.innerHTML = this.filteredOrders.map(order => this.createOrderCard(order)).join('');
        
        // Add click event listeners to order cards
        document.querySelectorAll('.order-card').forEach(card => {
            card.addEventListener('click', () => this.showOrderDetails(card.dataset.orderId));
        });
    }
    
    createOrderCard(order) {
        return `
            <div class="order-card" data-order-id="${order.id}">
                <div class="order-header">
                    <div>
                        <span class="order-id">Order #${order.id}</span>
                        <span class="order-date">${new Date(order.date).toLocaleDateString()}</span>
                    </div>
                    <span class="order-status status-${order.status.toLowerCase()}">${order.status}</span>
                </div>
                <div class="order-summary">
                    <div class="order-summary-item">
                        <span class="order-summary-label">Items</span>
                        <span class="order-summary-value">${order.items.length}</span>
                    </div>
                    <div class="order-summary-item">
                        <span class="order-summary-label">Total</span>
                        <span class="order-summary-value">$${order.total.toFixed(2)}</span>
                    </div>
                    <div class="order-summary-item">
                        <span class="order-summary-label">Shipping</span>
                        <span class="order-summary-value">${order.shippingAddress}</span>
                    </div>
                </div>
            </div>
        `;
    }
    
    showOrderDetails(orderId) {
        const order = this.orders.find(o => o.id === orderId);
        if (!order) return;
        
        this.orderDetails.innerHTML = `
            <h2>Order #${order.id}</h2>
            <div class="order-details">
                <div class="order-info">
                    <p><strong>Date:</strong> ${new Date(order.date).toLocaleString()}</p>
                    <p><strong>Status:</strong> <span class="order-status status-${order.status.toLowerCase()}">${order.status}</span></p>
                    <p><strong>Shipping Address:</strong> ${order.shippingAddress}</p>
                </div>
                
                <div class="order-items">
                    <h3>Items</h3>
                    ${order.items.map(item => `
                        <div class="order-item">
                            <img src="${item.image}" alt="${item.name}" class="order-item-image">
                            <div class="order-item-details">
                                <span class="order-item-name">${item.name}</span>
                                <span class="order-item-price">$${item.price.toFixed(2)}</span>
                                <span class="order-item-quantity">Quantity: ${item.quantity}</span>
                            </div>
                            <div class="order-item-total">
                                $${(item.price * item.quantity).toFixed(2)}
                            </div>
                        </div>
                    `).join('')}
                </div>
                
                <div class="order-totals">
                    <div class="order-total-row">
                        <span>Subtotal</span>
                        <span>$${order.subtotal.toFixed(2)}</span>
                    </div>
                    <div class="order-total-row">
                        <span>Shipping</span>
                        <span>$${order.shipping.toFixed(2)}</span>
                    </div>
                    <div class="order-total-row">
                        <span>Tax</span>
                        <span>$${order.tax.toFixed(2)}</span>
                    </div>
                    <div class="order-total-row">
                        <span>Total</span>
                        <span>$${order.total.toFixed(2)}</span>
                    </div>
                </div>
            </div>
        `;
        
        this.orderModal.style.display = 'block';
    }
    
    showError(message) {
        // Implement error notification
        console.error(message);
    }
}

// Initialize order manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const orderManager = new OrderManager();
}); 