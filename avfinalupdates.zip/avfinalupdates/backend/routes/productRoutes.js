const express = require('express');
const router = express.Router();
const fs = require('fs').promises;
const path = require('path');

// Helper function to read products data
async function getProducts() {
    try {
        const data = await fs.readFile(path.join(__dirname, '../data/products.json'), 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading products:', error);
        return [];
    }
}

// Get all products
router.get('/products', async (req, res) => {
    try {
        const products = await getProducts();
        res.json(products);
    } catch (error) {
        console.error('Error getting products:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Get product by ID
router.get('/products/:id', async (req, res) => {
    try {
        const products = await getProducts();
        const product = products.find(p => p.id === Number(req.params.id));

        
        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }
        
        res.json(product);
    } catch (error) {
        console.error('Error getting product:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Get products by category
router.get('/products/category/:category', async (req, res) => {
    try {
        const products = await getProducts(); // Add this line
        const category = req.params.category.toLowerCase();
        const categoryProducts = products.filter(p => p.category.toLowerCase() === category);
        res.json(categoryProducts);
    } catch (error) {
        console.error('Error getting products by category:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Search products
router.get('/products/search/:query', async (req, res) => {
    try {
        const products = await getProducts();
        const query = req.params.query.toLowerCase();
        
        const searchResults = products.filter(product => 
            product.name.toLowerCase().includes(query) ||
            product.description.toLowerCase().includes(query)
        );
        
        res.json(searchResults);
    } catch (error) {
        console.error('Error searching products:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router; 