class Product {
    constructor(data) {
        this.id = data.id;
        this.name = data.name;
        this.category = data.category;
        this.price = data.price;
        this.description = data.description;
        this.image = data.image;
        this.specifications = data.specifications || {};
        this.stock = data.stock || 0;
        this.isNew = data.isNew || false;
    }
}

// Main Product Catalogue System
class ProductCatalogue {
    constructor() {
        this.products = [];
        this.filteredProducts = [];
        this.currentPage = 1;
        this.productsPerPage = 8;
        this.searchTerm = '';
        this.selectedCategory = '';
        this.sortBy = 'name-asc';
        this.cart = new Cart();

        // DOM Elements
        this.productGrid = document.getElementById('productGrid');
        this.singleProductView = document.getElementById('singleProduct');
        this.searchInput = document.getElementById('searchInput');
        this.categoryFilter = document.getElementById('categoryFilter');
        this.sortBySelect = document.getElementById('sortBy');
        this.prevPageBtn = document.getElementById('prevPage');
        this.nextPageBtn = document.getElementById('nextPage');
        this.pageInfo = document.getElementById('pageInfo');
        this.modal = document.getElementById('productModal');

        // Initialize with mock data
        this.initializeMockData();
        this.init();
    }

    initializeMockData() {
        // Mock product data for testing
        this.products = [
            new Product({
                id: '1',
                name: 'Laptop Pro',
                price: 1200,
                category: 'laptops',
                image: 'https://via.placeholder.com/250x200/0066cc/ffffff?text=Laptop+Pro',
                description: 'A high-performance laptop for professionals with excellent battery life and performance.',
                specifications: { CPU: 'Intel i7', RAM: '16GB', Storage: '512GB SSD' },
                stock: 10,
                isNew: true
            }),
            new Product({
                id: '2',
                name: 'Smartphone X',
                price: 800,
                category: 'phones',
                image: 'https://via.placeholder.com/250x200/cc6600/ffffff?text=Smartphone+X',
                description: 'The latest smartphone with an amazing camera and 5G connectivity.',
                specifications: { Storage: '128GB', Camera: '48MP', Display: '6.1 inch' },
                stock: 15,
                isNew: true
            }),
            new Product({
                id: '3',
                name: 'Wireless Headphones',
                price: 150,
                category: 'accessories',
                image: 'https://via.placeholder.com/250x200/009900/ffffff?text=Headphones',
                description: 'Comfortable over-ear headphones with active noise cancellation.',
                specifications: { Battery: '30 hours', Connectivity: 'Bluetooth 5.0', Weight: '250g' },
                stock: 25,
                isNew: false
            }),
            new Product({
                id: '4',
                name: 'Digital Camera',
                price: 600,
                category: 'cameras',
                image: 'https://via.placeholder.com/250x200/cc0066/ffffff?text=Camera',
                description: 'Capture stunning photos and videos with this professional camera.',
                specifications: { Resolution: '24MP', Lens: '18-55mm', Video: '4K' },
                stock: 8,
                isNew: false
            }),
            new Product({
                id: '5',
                name: 'Smart Refrigerator',
                price: 2000,
                category: 'appliances',
                image: 'https://via.placeholder.com/250x200/666666/ffffff?text=Smart+Fridge',
                description: 'A smart fridge with built-in touchscreen and energy efficiency.',
                specifications: { Capacity: '500L', Energy: 'A+++', Features: 'WiFi, Touch Screen' },
                stock: 3,
                isNew: true
            }),
            new Product({
                id: '6',
                name: 'Gaming Mouse',
                price: 80,
                category: 'accessories',
                image: 'https://via.placeholder.com/250x200/990099/ffffff?text=Gaming+Mouse',
                description: 'High-precision gaming mouse with RGB lighting.',
                specifications: { DPI: '16000', Buttons: '8', Connectivity: 'USB-C' },
                stock: 20,
                isNew: false
            })
        ];

        this.filteredProducts = [...this.products];
    }

    async init() {
        this.addEventListeners();
        this.applyFilters();
    }

    addEventListeners() {
        // Search functionality
        if (this.searchInput) {
            let debounceTimeout;
            this.searchInput.addEventListener('input', () => {
                clearTimeout(debounceTimeout);
                debounceTimeout = setTimeout(() => this.handleSearch(), 300);
            });
        }

        // Filters and sorting
        if (this.categoryFilter) {
            this.categoryFilter.addEventListener('change', () => this.handleFilter());
        }
        
        if (this.sortBySelect) {
            this.sortBySelect.addEventListener('change', () => this.handleSort());
        }

        // Pagination
        if (this.prevPageBtn) {
            this.prevPageBtn.addEventListener('click', () => this.previousPage());
        }
        
        if (this.nextPageBtn) {
            this.nextPageBtn.addEventListener('click', () => this.nextPage());
        }

        // Modal close handlers
        if (this.modal) {
            const closeModal = this.modal.querySelector('.close');
            if (closeModal) {
                closeModal.addEventListener('click', () => this.closeProductModal());
            }
            
            window.addEventListener('click', (e) => {
                if (e.target === this.modal) this.closeProductModal();
            });
        }
    }

    handleSearch() {
        this.searchTerm = this.searchInput.value.toLowerCase().trim();
        this.currentPage = 1;
        this.applyFilters();
    }

    handleFilter() {
        this.selectedCategory = this.categoryFilter.value;
        this.currentPage = 1;
        this.applyFilters();
    }

    handleSort() {
        this.sortBy = this.sortBySelect.value;
        this.applyFilters();
    }

    applyFilters() {
        this.filteredProducts = this.products.filter(product => {
            const matchesSearch = !this.searchTerm || 
                product.name.toLowerCase().includes(this.searchTerm) ||
                product.description.toLowerCase().includes(this.searchTerm);
            
            const matchesCategory = !this.selectedCategory || 
                this.selectedCategory === 'all' || 
                product.category === this.selectedCategory;
            
            return matchesSearch && matchesCategory;
        });

        this.sortProducts();
        this.currentPage = 1;
        this.updatePagination();
        this.renderProducts();
    }

    sortProducts() {
        const [field, direction] = this.sortBy.split('-');
        this.filteredProducts.sort((a, b) => {
            let comparison = 0;
            if (field === 'name') {
                comparison = a.name.localeCompare(b.name);
            } else if (field === 'price') {
                comparison = a.price - b.price;
            }
            return direction === 'asc' ? comparison : -comparison;
        });
    }

    updatePagination() {
        const totalPages = Math.max(1, Math.ceil(this.filteredProducts.length / this.productsPerPage));
        
        if (this.prevPageBtn) this.prevPageBtn.disabled = this.currentPage <= 1;
        if (this.nextPageBtn) this.nextPageBtn.disabled = this.currentPage >= totalPages;
        if (this.pageInfo) this.pageInfo.textContent = `Page ${this.currentPage} of ${totalPages}`;
    }

    previousPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.updatePagination();
            this.renderProducts();
        }
    }

    nextPage() {
        const totalPages = Math.ceil(this.filteredProducts.length / this.productsPerPage);
        if (this.currentPage < totalPages) {
            this.currentPage++;
            this.updatePagination();
            this.renderProducts();
        }
    }

    renderProducts() {
        if (!this.productGrid) return;

        const start = (this.currentPage - 1) * this.productsPerPage;
        const end = start + this.productsPerPage;
        const productsToShow = this.filteredProducts.slice(start, end);

        if (productsToShow.length === 0) {
            this.productGrid.innerHTML = `<p class="no-products">No products found.</p>`;
            if (this.pageInfo) this.pageInfo.textContent = '';
            if (this.prevPageBtn) this.prevPageBtn.disabled = true;
            if (this.nextPageBtn) this.nextPageBtn.disabled = true;
            return;
        }

        this.productGrid.innerHTML = productsToShow
            .map(product => this.createProductCard(product))
            .join('');

        // Show product grid, hide single product view
        if (this.productGrid) this.productGrid.style.display = 'grid';
        if (this.singleProductView) this.singleProductView.style.display = 'none';
    }

    createProductCard(product) {
        return `
            <div class="product-card">
                <img src="${product.image}" alt="${product.name}" class="product-image" />
                <div class="product-info">
                    <h3 class="product-title">${product.name}</h3>
                    <p class="product-price">$${product.price.toFixed(2)}</p>
                    ${product.isNew ? '<span class="new-badge">NEW</span>' : ''}
                    <div class="product-buttons">
                        <button class="btn btn-secondary" onclick="productCatalogue.showProductDetails('${product.id}')">View Details</button>
                        <button class="btn btn-primary" onclick="productCatalogue.addToCart('${product.id}')">Add to Cart</button>
                    </div>
                </div>
            </div>
        `;
    }

    showProductDetails(productId) {
        const product = this.products.find(p => p.id === productId);
        if (!product) {
            console.error('Product not found:', productId);
            return;
        }

        // If we have a modal, use it
        if (this.modal) {
            const productDetails = this.modal.querySelector('#productDetails') || this.modal;
            productDetails.innerHTML = this.createProductDetailView(product);
            this.modal.style.display = 'block';
        } 
        // Otherwise use the single product view
        else if (this.singleProductView) {
            this.singleProductView.innerHTML = this.createProductDetailView(product);
            this.productGrid.style.display = 'none';
            this.singleProductView.style.display = 'block';
        }
    }

    createProductDetailView(product) {
        const specsHtml = Object.keys(product.specifications).length > 0 
            ? `<div class="product-specs">
                <h3>Specifications</h3>
                <ul>
                    ${Object.entries(product.specifications)
                        .map(([key, value]) => `<li><strong>${key}:</strong> ${value}</li>`)
                        .join('')}
                </ul>
               </div>`
            : '';

        return `
            <div class="product-details">
                <img src="${product.image}" alt="${product.name}" class="product-details-image" />
                <div class="product-details-info">
                    <h2>${product.name}</h2>
                    <p class="product-details-price">$${product.price.toFixed(2)}</p>
                    <p class="product-details-description">${product.description}</p>
                    <p class="product-stock">Stock: ${product.stock > 0 ? product.stock + ' available' : 'Out of Stock'}</p>
                    ${specsHtml}
                    <div class="product-actions">
                        <button class="btn btn-primary" 
                                onclick="productCatalogue.addToCart('${product.id}')"
                                ${product.stock === 0 ? 'disabled' : ''}>
                            Add to Cart
                        </button>
                        <button class="btn btn-secondary" onclick="productCatalogue.goBackToProductList()">
                            Back to Products
                        </button>
                    </div>
                </div>
            </div>
        `;
    }

    closeProductModal() {
        if (this.modal) {
            this.modal.style.display = 'none';
        }
    }

    goBackToProductList() {
        this.closeProductModal();
        if (this.productGrid) this.productGrid.style.display = 'grid';
        if (this.singleProductView) this.singleProductView.style.display = 'none';
    }

    addToCart(productId) {
        const product = this.products.find(p => p.id === productId);
        if (!product) {
            console.error('Product not found:', productId);
            return;
        }

        if (product.stock <= 0) {
            alert('Sorry, this product is out of stock.');
            return;
        }

        this.cart.addItem(product, 1);
        
        // Show success message
        alert(`${product.name} added to cart!`);
        
        // Update stock (for demo purposes)
        product.stock -= 1;
        
        console.log('Cart contents:', this.cart.items);
    }

    // Global filter function for category buttons
    filterProducts(category) {
        this.selectedCategory = category;
        this.currentPage = 1;
        this.applyFilters();
    }
}

// Initialize the product catalogue when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.productCatalogue = new ProductCatalogue();
});

// Global functions for backwards compatibility
window.filterProducts = (category) => {
    if (window.productCatalogue) {
        window.productCatalogue.filterProducts(category);
    }
};

window.viewProductDetails = (productId) => {
    if (window.productCatalogue) {
        window.productCatalogue.showProductDetails(productId);
    }
};

window.addToCart = (productId) => {
    if (window.productCatalogue) {
        window.productCatalogue.addToCart(productId);
    }
};

window.goBackToProductList = () => {
    if (window.productCatalogue) {
        window.productCatalogue.goBackToProductList();
    }
};